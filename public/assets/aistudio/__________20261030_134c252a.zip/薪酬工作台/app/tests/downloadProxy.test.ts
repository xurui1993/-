import assert from 'node:assert/strict';
import http, { type Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import test from 'node:test';
import express from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import { createDownloadProxy, isDownloadProxyPath } from '../server/downloadProxy.ts';

test('download route filter includes once-encoded paths and fails malformed paths closed', () => {
  for (const path of ['/api/run', '/api/parttime/preparations/abc/resolve', '/api/parttime/plan', '/api/fengshen-downloads', '/api/fengshen-downloads/account/status',
    '/api/fengshen-downloads%2Faccount%2Fbootstrap', '/%61pi/fengshen-downloads/runs', '/api/%ZZ']) {
    assert.equal(isDownloadProxyPath(path), true, path);
  }
  for (const path of ['/api/fengshen-downloads-other', '/api/ordinary?next=/api/fengshen-downloads',
    '/api/fengshen-download%2573/runs']) assert.equal(isDownloadProxyPath(path), false, path);
});

async function listen(server: Server) {
  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  return (server.address() as AddressInfo).port;
}

async function close(server: Server) {
  server.closeAllConnections();
  await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
}

test('download proxy preserves host/cookie/body and replaces spoofed client identity', async t => {
  const backend = http.createServer(async (req, res) => {
    let body = '';
    for await (const chunk of req) body += chunk.toString();
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ headers: req.headers, body }));
  });
  const backendPort = await listen(backend);
  t.after(() => close(backend));
  const app = express();
  const options = { target: `http://127.0.0.1:${backendPort}`, changeOrigin: true };
  app.use(createDownloadProxy(options, 'synthetic-shared-secret'));
  app.use(createProxyMiddleware({ pathFilter: '/api', ...options }));
  const frontend = http.createServer(app);
  const frontendPort = await listen(frontend);
  t.after(() => close(frontend));
  for (const path of ['/api/fengshen-downloads/account/bootstrap', '/api/fengshen-downloads%2Faccount%2Fbootstrap']) {
    const result: any = await new Promise((resolve, reject) => {
      const body = JSON.stringify({ username: 'synthetic', password: 'only-in-synthetic-test' });
      const outgoing = http.request({ host: '127.0.0.1', port: frontendPort, path, method: 'POST', headers: {
        Host: '192.168.1.8:3000', Origin: 'http://192.168.1.8:3000', Cookie: 'fengshen_download_session=synthetic-cookie',
        'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body),
        'X-Download-Proxy-Secret': 'forged', 'X-Download-Client-Address': '192.0.2.99',
        Forwarded: 'for=127.0.0.1', 'X-Forwarded-For': '127.0.0.1', 'X-Forwarded-Proto': 'https',
      } }, response => {
        let value = '';
        response.on('data', chunk => { value += chunk; });
        response.on('end', () => resolve(JSON.parse(value)));
      });
      outgoing.once('error', reject);
      outgoing.end(body);
    });
    assert.equal(result.headers.host, '192.168.1.8:3000');
    assert.equal(result.headers.origin, 'http://192.168.1.8:3000');
    assert.equal(result.headers.cookie, 'fengshen_download_session=synthetic-cookie');
    assert.equal(result.headers['x-download-proxy-secret'], 'synthetic-shared-secret');
    assert.equal(result.headers['x-download-client-address'], '127.0.0.1');
    assert.equal(result.headers.forwarded, undefined);
    assert.equal(result.headers['x-forwarded-for'], undefined);
    assert.equal(result.headers['x-forwarded-proto'], undefined);
    assert.equal(JSON.parse(result.body).username, 'synthetic');
  }
});
