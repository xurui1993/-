import assert from 'node:assert/strict';
import test from 'node:test';
import {
  validateDeductionRows,
  connectionLabel,
  connectionSummary,
  SYSTEM_META,
  computeBillingPeriodRange,
  BUILTIN_DOWNLOAD_SCENARIOS,
  inferDatasetSystemTag,
  GENERATION_REPORT_CARDS,
  PAYROLL_MODE_CARDS,
  extractDeductionColumns,
  classifyTemplateCategory,
  getWorkbenchBreadcrumb,
  getPayrollSidebarBadge,
} from '../src/lib/workbench';

test('connection summary distinguishes signed-out, saved, unknown and validated sessions', () => {
  assert.equal(connectionSummary([{state:'signed_out'},{state:'saved'}]),'需连接');
  assert.equal(connectionSummary([{state:'ready'},{offline:true,state:'ready'}]),'状态未知');
  assert.equal(connectionSummary([{state:'ready'},{state:'ready'}]),'连接正常');
  assert.equal(connectionSummary([{state:'ready'},{state:'starting'}]),'连接中');
  assert.equal(connectionSummary([{state:'ready'},{state:'waiting_login'}]),'需验证');
});
import { isDownloadProxyPath } from '../server/downloadProxy.ts';

test('deduction editing preserves identifiers, custom columns and keyword flags', () => {
  const rows = [{ 城市: '测试城', 团队名称: '测试站', 团队ID: '00123', 投诉: 5, 投诉_isKw: true, 说明: '保留' }];
  assert.equal(validateDeductionRows(rows), rows);
  assert.equal(rows[0].团队ID, '00123');
  assert.throws(() => validateDeductionRows([rows[0], rows[0]]), /重复/);
  assert.throws(() => validateDeductionRows([{ ...rows[0], 投诉: NaN }]), /有效数字/);
  assert.throws(() => validateDeductionRows([{ 团队名称: '站点' }]), /城市/);
});

test('saved sessions remain unverified and network errors are not logged-out states', () => {
  assert.equal(connectionLabel('saved'), '待验证');
  assert.equal(connectionLabel('ready'), '已连接');
  assert.equal(connectionLabel('planned'), '待接入');
  assert.equal(connectionLabel('refreshing'), '检查中');
  assert.equal(connectionLabel('waiting_login'), '需要验证');
  assert.equal(connectionLabel('error'), '连接异常');
});

test('workbench writes preserve browser origin through the authenticated proxy', () => {
  assert.equal(isDownloadProxyPath('/api/workbench/deductions'), true);
  assert.equal(isDownloadProxyPath('/api/workbench/batches/abc/deductions'), true);
  assert.equal(isDownloadProxyPath('/api/workbench-other'), false);
});

test('source metadata separates Xiaoxiang online download from manual payroll and keeps Baize standalone', () => {
  assert.deepEqual(
    SYSTEM_META.map(item => item.label),
    ['风神', '蓝橙', '白泽', '小象灯塔', '灯塔'],
  );
  assert.equal(SYSTEM_META.find(item => item.key === 'lanorange')?.businessLine, '原雷神');
  assert.match(SYSTEM_META.find(item => item.key === 'dengta')!.description, /手动上传/);
  assert.match(SYSTEM_META.find(item => item.key === 'baize')!.description, /独立下载/);
});

test('billing period presets compute accurate start and end dates across month boundaries', () => {
  assert.deepEqual(computeBillingPeriodRange('last_full_month', '2026-03-18'), {
    start: '2026-02-01',
    end: '2026-02-28',
    label: '上月整月',
  });
  assert.deepEqual(computeBillingPeriodRange('last_full_month', '2026-01-10'), {
    start: '2025-12-01',
    end: '2025-12-31',
    label: '上月整月',
  });
  assert.deepEqual(computeBillingPeriodRange('current_first_half', '2026-05-22'), {
    start: '2026-05-01',
    end: '2026-05-15',
    label: '本月1-15日',
  });
  assert.deepEqual(computeBillingPeriodRange('last_second_half', '2026-05-22'), {
    start: '2026-04-16',
    end: '2026-04-30',
    label: '上月16-月末',
  });
  assert.deepEqual(computeBillingPeriodRange('current_month_to_date', '2026-05-22'), {
    start: '2026-05-01',
    end: '2026-05-22',
    label: '本月至今',
  });
});

test('built-in scenario presets and dataset system attribution map to 2-char system names', () => {
  assert.equal(BUILTIN_DOWNLOAD_SCENARIOS.length, 3);
  assert.equal(inferDatasetSystemTag('delivery_fee'), '风神');
  assert.equal(inferDatasetSystemTag('lanorange_rider_profile'), '蓝橙');
  assert.equal(inferDatasetSystemTag('shangyi_employees'), '白泽');
  assert.equal(inferDatasetSystemTag('delivery_fee', 'xiaoxiang'), '灯塔');
  assert.equal(inferDatasetSystemTag('rider_daily'), '小象灯塔');
});

test('report generation cards and payroll mode cards expose structured metadata and localized labels', () => {
  assert.equal(GENERATION_REPORT_CARDS.length, 3);
  assert.deepEqual(
    GENERATION_REPORT_CARDS.map(item => item.id),
    ['payment_binding', 'abnormal_followup', 'abnormal_riders'],
  );
  assert.equal(PAYROLL_MODE_CARDS.length, 3);
  assert.ok(PAYROLL_MODE_CARDS.every(card => !card.subtitle.toLowerCase().includes('template')));
});

test('extractDeductionColumns collects ordered numeric columns across sites while excluding reserved fields', () => {
  const rows: import('../src/lib/workbench').DeductionRow[] = [
    { 城市: '宁波', 团队名称: '海曙站', 团队ID: '001', 投诉: 50, 投诉_isKw: true, 差评: 20, 说明: '备注' },
    { 城市: '杭州', 团队名称: '西湖站', 投诉: 30, 迟到: 10 },
  ];
  assert.deepEqual(extractDeductionColumns(rows), {
    metaColumns: ['城市', '团队名称', '团队ID'],
    deductionColumns: ['投诉', '差评', '迟到'],
  });
});

test('classifyTemplateCategory categorizes templates by business line and payroll usage', () => {
  assert.equal(classifyTemplateCategory('美团小象兼职薪资核算.xlsx').tag, '美团小象');
  assert.equal(classifyTemplateCategory('淘宝闪购风神配送费模板.xlsx').tag, '淘宝闪购');
  assert.equal(classifyTemplateCategory('通用考勤导出表.xlsx').tag, '通用模板');
});

test('breadcrumb and sidebar status helpers reflect active view and batch state', () => {
  assert.equal(getWorkbenchBreadcrumb('create', 'download').title, '资料下载采集');
  assert.equal(getWorkbenchBreadcrumb('create', 'generate').title, '业务报表生成');
  assert.equal(getWorkbenchBreadcrumb('create', 'payroll').title, '兼职薪资结算');
  assert.equal(getWorkbenchBreadcrumb('history', 'download').title, '任务与产出中心');

  assert.equal(getPayrollSidebarBadge('calculated', false)?.label, '已出表');
  assert.equal(getPayrollSidebarBadge('calculating', true)?.tone, 'active');
  assert.equal(getPayrollSidebarBadge(undefined, false), null);
});
