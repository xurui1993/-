import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {cleanBuild} from '../scripts/clean-build.mjs';

function fixture(){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'layout-source-test-'));
  for(const [name,value] of Object.entries({'backend/main.py':'# synthetic','dist/server.js':'synthetic server','dist/index.html':'synthetic index','backend/.local_auth/platform.dpapi':'private marker','data/config.json':'private config','uploads/input.xlsx':'private input'})){
    const file=path.join(root,name);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,value);
  }
  return root;
}
test('clean removes only the generated build, retaining code and private data',()=>{
  const root=fixture();try{cleanBuild(root);assert(!fs.existsSync(path.join(root,'dist')));for(const name of ['backend/main.py','backend/.local_auth/platform.dpapi','data/config.json','uploads/input.xlsx'])assert(fs.existsSync(path.join(root,name)));}finally{fs.rmSync(root,{recursive:true});}
});
test('linked build output cannot be recursively cleaned',()=>{
  const root=fixture(),outside=fs.mkdtempSync(path.join(os.tmpdir(),'layout-outside-test-'));
  try{
    fs.writeFileSync(path.join(outside,'secret'),'synthetic');
    fs.rmSync(path.join(root,'dist'),{recursive:true});fs.symlinkSync(outside,path.join(root,'dist'),'junction');assert.throws(()=>cleanBuild(root),/directory link/);assert.equal(fs.readFileSync(path.join(outside,'secret'),'utf8'),'synthetic');
  }finally{fs.rmSync(root,{recursive:true});fs.rmSync(outside,{recursive:true});}
});
