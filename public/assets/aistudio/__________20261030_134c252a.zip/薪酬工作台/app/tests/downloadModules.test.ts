import test from 'node:test';
import assert from 'node:assert/strict';
import {moduleAcceptsDataset,matchesRecordModule} from '../src/lib/downloadModules';
test('platform downloads exclude reports and other platform sources',()=>{
  assert(moduleAcceptsDataset('invitation_records','fengshen'));
  assert(moduleAcceptsDataset('attendance_detail','fengshen'));
  assert(moduleAcceptsDataset('lanorange_part_price','lanorange'));
  assert(moduleAcceptsDataset('baize_employees','baize'));
  assert(moduleAcceptsDataset('rider_daily','xiaoxiang'));
  assert(!moduleAcceptsDataset('payment_binding','fengshen'));
  assert(!moduleAcceptsDataset('abnormal_riders','lanorange'));
  assert(!moduleAcceptsDataset('rider_daily','fengshen'));
});
test('local history distinguishes reports from source platforms and keeps legacy mixed downloads',()=>{
  const report={kind:'generate',datasets:['abnormal_followup','lanorange_part_price']};
  assert(matchesRecordModule(report,'generate'));assert(!matchesRecordModule(report,'lanorange'));
  const legacy={datasets:['delivery_fee','lanorange_part_price']};
  assert(matchesRecordModule(legacy,'fengshen'));assert(matchesRecordModule(legacy,'lanorange'));assert(!matchesRecordModule(legacy,'baize'));
  assert(!matchesRecordModule({kind:'payroll',datasets:['delivery_fee']},'fengshen'));
  assert(matchesRecordModule(report));
});
