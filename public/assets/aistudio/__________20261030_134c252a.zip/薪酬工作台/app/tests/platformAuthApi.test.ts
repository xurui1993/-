import test from 'node:test';
import assert from 'node:assert/strict';
import {platformAuthRequest,PlatformAuthError} from '../src/lib/platformAuthApi';

test('authentication command timeout is unconfirmed and sends exactly once',async()=>{
 let calls=0;
 const fetcher=async(_url:string,init?:RequestInit)=>{calls++;return new Promise<Response>((_resolve,reject)=>init!.signal!.addEventListener('abort',()=>reject(new DOMException('aborted','AbortError'))));};
 await assert.rejects(()=>platformAuthRequest(fetcher,'/auth',{action:'login'},10),(e:unknown)=>e instanceof PlatformAuthError && e.uncertain && /不要重复/.test(e.message));
 assert.equal(calls,1);
});
test('read-only failure does not imply a credential mutation',async()=>{
 let calls=0;await assert.rejects(()=>platformAuthRequest(async()=>{calls++;throw Error('unavailable');},'/status'),(e:unknown)=>e instanceof PlatformAuthError && !e.uncertain);
 assert.equal(calls,1);
});
test('server-side write failure is unconfirmed, validation rejection is definite',async()=>{
 for(const status of [409,500]){
  await assert.rejects(()=>platformAuthRequest(async()=>new Response(JSON.stringify({detail:'synthetic failure'}),{status}),'/disconnect',{}),(e:unknown)=>e instanceof PlatformAuthError && e.uncertain===(status>=500));
 }
});
test('malformed successful mutation response never causes an automatic retry',async()=>{
 let calls=0;await assert.rejects(()=>platformAuthRequest(async()=>{calls++;return new Response('not-json');},'/start',{}),(e:unknown)=>e instanceof PlatformAuthError && e.uncertain);assert.equal(calls,1);
});
test('successful authentication response preserves command correlation',async()=>{
 const data=await platformAuthRequest<{command_id:number}>(async()=>new Response('{"command_id":7}'),'/interact',{action:'inspect'});assert.equal(data.command_id,7);
});
