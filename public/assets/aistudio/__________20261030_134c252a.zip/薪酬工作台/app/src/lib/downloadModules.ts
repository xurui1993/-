import { datasetGroup } from './downloadCenterLogic';
import { inferTaskKind } from './taskCatalog';

export const DOWNLOAD_PLATFORMS = [
  {id:'fengshen',label:'风神'}, {id:'lanorange',label:'蓝橙'},
  {id:'baize',label:'白泽'}, {id:'xiaoxiang',label:'小象灯塔'},
] as const;
export type DownloadPlatform = typeof DOWNLOAD_PLATFORMS[number]['id'];
export type RecordModule = DownloadPlatform | 'generate';
export function moduleAcceptsDataset(id:string, platform:DownloadPlatform) {
  return inferTaskKind([id])==='download' && datasetGroup(id)===platform;
}
export function matchesRecordModule(record:{kind?:string;datasets:string[]},module?:RecordModule) {
  if(!module)return true;
  const kind=record.kind || inferTaskKind(record.datasets);
  if(module==='generate')return kind==='generate';
  // Historic mixed-platform downloads remain visible in each relevant module.
  return kind==='download' && record.datasets.some(id=>moduleAcceptsDataset(id,module));
}
