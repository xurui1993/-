export type DeductionRow = Record<string, string | number | boolean | null>;
export function validateDeductionRows(value: unknown): DeductionRow[] {
  if (!Array.isArray(value) || !value.length) throw new Error('配置必须包含至少一个站点');
  const keys = new Set<string>();
  for (const row of value) {
    if (!row || typeof row !== 'object' || Array.isArray(row) || !String(row['城市'] || '').trim() || !String(row['团队名称'] || '').trim()) throw new Error('每个站点都需要城市和团队名称');
    const key = JSON.stringify([row['城市'], row['团队名称'], row['团队ID'] || '']);
    if (keys.has(key)) throw new Error('存在重复站点，请核对城市、团队名称和团队 ID');
    keys.add(key);
    for (const value of Object.values(row)) {
      if (value !== null && !['string', 'number', 'boolean'].includes(typeof value)) throw new Error('配置字段必须为文本、数字或开关');
      if (typeof value === 'number' && !Number.isFinite(value)) throw new Error('金额必须为有效数字');
    }
  }
  return value;
}

export function connectionLabel(state?: string) {
  if (state === 'partial') return '部分已验证';
  if (state === 'ready') return '已连接';
  if (state === 'unknown') return '状态未知';
  if (state === 'planned') return '待接入';
  if (['saved'].includes(state || '')) return '待验证';
  if (['starting', 'refreshing', 'sending', 'verifying'].includes(state || '')) return '检查中';
  if (['waiting_login', 'login_required', 'sms_sent', 'manual_required'].includes(state || '')) return '需要验证';
  if (state === 'error') return '连接异常';
  return '未连接';
}

export function connectionSummary(systems: {state?: string; offline?: boolean}[]): string {
  if (!systems.length || systems.some(system => system.offline || system.state === 'unknown' || !system.state)) return '状态未知';
  if (systems.every(system => system.state === 'ready')) return '连接正常';
  if (systems.some(system => system.state === 'error')) return '连接异常';
  if (systems.some(system => ['partial','waiting_login', 'login_required', 'sms_sent', 'manual_required'].includes(system.state || ''))) return '需验证';
  if (systems.some(system => ['starting', 'refreshing'].includes(system.state || ''))) return '连接中';
  return '需连接';
}

export type SystemKey = 'fengshen' | 'lanorange' | 'baize' | 'xiaoxiang' | 'dengta';

export interface SystemMetaItem {
  key: SystemKey;
  label: '风神' | '蓝橙' | '白泽' | '小象灯塔' | '灯塔';
  businessLine: string;
  description: string;
  planned?: boolean;
}

export const SYSTEM_META: SystemMetaItem[] = [
  { key: 'fengshen', label: '风神', businessLine: '淘宝闪购自有系统', description: '配送费、违规扣款、月度UB账单、骑手绑定、欺诈/问题单等核心账单数据源。' },
  { key: 'lanorange', label: '蓝橙', businessLine: '原雷神', description: '原雷神 · 骑手人事档案、兼职价格档案、离职/批量离职、请假等内部人事数据源。' },
  { key: 'baize', label: '白泽', businessLine: '商翼系统', description: '白泽全部员工原表独立下载；不随兼职核算自动补齐。' },
  { key: 'xiaoxiang', label: '小象灯塔', businessLine: '美团小象超市系统', description: '商配送骑手订单明细与日维度骑手分析，独立下载。' },
  { key: 'dengta', label: '灯塔', businessLine: '美团小象超市系统', description: '小象薪资申请表与配送资料手动上传核算。' },
];

export type BillingPeriodPreset =
  | 'last_full_month'
  | 'current_first_half'
  | 'last_second_half'
  | 'current_month_to_date';

function pad2(n: number): string {
  return String(n).padStart(2, '0');
}

function daysInMonth(year: number, month1Based: number): number {
  return new Date(Date.UTC(year, month1Based, 0)).getUTCDate();
}

export function computeBillingPeriodRange(
  preset: BillingPeriodPreset,
  referenceDateStr: string,
): { start: string; end: string; label: string } {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(referenceDateStr.trim());
  const now = match
    ? { year: Number(match[1]), month: Number(match[2]), day: Number(match[3]) }
    : { year: 2026, month: 1, day: 15 };

  const prevYear = now.month === 1 ? now.year - 1 : now.year;
  const prevMonth = now.month === 1 ? 12 : now.month - 1;
  const prevMonthDays = daysInMonth(prevYear, prevMonth);

  if (preset === 'last_full_month') {
    return {
      start: `${prevYear}-${pad2(prevMonth)}-01`,
      end: `${prevYear}-${pad2(prevMonth)}-${pad2(prevMonthDays)}`,
      label: '上月整月',
    };
  }
  if (preset === 'current_first_half') {
    return {
      start: `${now.year}-${pad2(now.month)}-01`,
      end: `${now.year}-${pad2(now.month)}-15`,
      label: '本月1-15日',
    };
  }
  if (preset === 'last_second_half') {
    return {
      start: `${prevYear}-${pad2(prevMonth)}-16`,
      end: `${prevYear}-${pad2(prevMonth)}-${pad2(prevMonthDays)}`,
      label: '上月16-月末',
    };
  }
  return {
    start: `${now.year}-${pad2(now.month)}-01`,
    end: `${now.year}-${pad2(now.month)}-${pad2(now.day)}`,
    label: '本月至今',
  };
}

export interface BuiltinScenarioPreset {
  id: string;
  name: string;
  systemTag: '风神' | '蓝橙';
  description: string;
  datasets: string[];
}

export const BUILTIN_DOWNLOAD_SCENARIOS: BuiltinScenarioPreset[] = [
  {
    id: 'shangou_monthly_payroll',
    name: '闪购月度核算包',
    systemTag: '风神',
    description: '配送费 + 违规扣款 + 月度UB账单 + 骑手风神绑定 + 骑手信息',
    datasets: ['delivery_fee', 'penalty', 'rider_monthly', 'receive_account', 'rider_info'],
  },
  {
    id: 'shangou_daily_monitor',
    name: '闪购日常监控包',
    systemTag: '风神',
    description: '骑手数据明细 + 欺诈单 + 问题单',
    datasets: ['rider_detail', 'fraud', 'problem'],
  },
  {
    id: 'lanorange_hr_full',
    name: '蓝橙人事全量包',
    systemTag: '蓝橙',
    description: '骑手档案 + 价格档案 + 离职/批量离职 + 请假全量表',
    datasets: [
      'lanorange_rider_archive',
      'lanorange_part_price',
      'lanorange_rider_quit',
      'lanorange_batch_quit',
      'lanorange_rider_leave',
    ],
  },
];

export function inferDatasetSystemTag(datasetId: string, mode?: string): '风神' | '蓝橙' | '白泽' | '小象灯塔' | '灯塔' {
  if (mode === 'xiaoxiang') return '灯塔';
  const normalized = (datasetId || '').toLowerCase();
  if (normalized === 'rider_daily' || normalized === 'rider_archive' || normalized === 'detail_orders' || normalized === 'detail_kesu' || normalized === 'detail_reviews') return '小象灯塔';
  if (normalized.includes('shangyi') || normalized.includes('baize')) return '白泽';
  if (normalized.startsWith('lanorange') || normalized === 'abnormal_riders' || normalized === 'part_price' || normalized === 'rider_profile') {
    return '蓝橙';
  }
  return '风神';
}

export interface GenerationReportCardMeta {
  id: 'payment_binding' | 'abnormal_followup' | 'abnormal_riders';
  title: string;
  systems: ('风神' | '蓝橙')[];
  granularity: string;
  summary: string;
  requiresCityAndDate: boolean;
}

export const GENERATION_REPORT_CARDS: GenerationReportCardMeta[] = [
  {
    id: 'payment_binding',
    title: '骑手支付绑定',
    systems: ['风神', '蓝橙'],
    granularity: '按城市 · 按月拆分',
    summary: '自动关联风神收薪绑定与原雷神人事档案，输出周期内有单骑手支付绑定表及多城汇总。',
    requiresCityAndDate: true,
  },
  {
    id: 'abnormal_followup',
    title: '异常骑手跟进',
    systems: ['风神', '蓝橙'],
    granularity: '按城市 · 按月拆分',
    summary: '以支付绑定为基准，关联物资租用、月度UB账单、价格与骑手档案，定位异常待跟进名单。',
    requiresCityAndDate: true,
  },
  {
    id: 'abnormal_riders',
    title: '异常骑手整理',
    systems: ['蓝橙'],
    granularity: '全部城市 · 全量交付',
    summary: '自动汇总原雷神 5 类离职、请假与骑手档案，无需风神登录即可生成全城异常整理工作簿。',
    requiresCityAndDate: false,
  },
];

export interface PayrollModeCardMeta {
  id: 'fengshen' | 'manual' | 'xiaoxiang';
  title: string;
  systems: ('风神' | '蓝橙' | '灯塔')[];
  subtitle: string;
  badge?: string;
}

export const PAYROLL_MODE_CARDS: PayrollModeCardMeta[] = [
  {
    id: 'fengshen',
    title: '淘宝闪购 · 自动齐套',
    systems: ['风神', '蓝橙'],
    subtitle: '上传薪资申请表后，自动拉取风神账单与原雷神人事档案',
    badge: '推荐',
  },
  {
    id: 'manual',
    title: '淘宝闪购 · 手动上传',
    systems: ['风神', '蓝橙'],
    subtitle: '随薪资申请表一并上传或逐项补传风神与原雷神原始资料',
  },
  {
    id: 'xiaoxiang',
    title: '美团小象 · 手动上传',
    systems: ['灯塔'],
    subtitle: '上传小象薪资申请表与日期配送单',
    badge: '独立引擎',
  },
];

export function extractDeductionColumns(rows: DeductionRow[]): {
  metaColumns: string[];
  deductionColumns: string[];
} {
  const metaColumns = ['城市', '团队名称', '团队ID'];
  const metaSet = new Set(metaColumns);
  const seen = new Set<string>();
  const deductionColumns: string[] = [];
  for (const row of rows) {
    for (const key of Object.keys(row)) {
      if (metaSet.has(key) || seen.has(key) || key.endsWith('_isKw') || key === '说明') continue;
      seen.add(key);
      deductionColumns.push(key);
    }
  }
  return { metaColumns, deductionColumns };
}

export function classifyTemplateCategory(filename: string): {
  tag: '淘宝闪购' | '美团小象' | '通用模板';
  badgeClass: string;
} {
  const lower = (filename || '').toLowerCase();
  if (lower.includes('小象') || lower.includes('美团') || lower.includes('xiaoxiang')) {
    return { tag: '美团小象', badgeClass: 'is-dengta' };
  }
  if (lower.includes('闪购') || lower.includes('风神') || lower.includes('template') || lower.includes('兼职')) {
    return { tag: '淘宝闪购', badgeClass: 'is-fengshen' };
  }
  return { tag: '通用模板', badgeClass: 'is-lanorange' };
}

export function getWorkbenchBreadcrumb(
  workspaceView: 'create' | 'history' | 'approval' | 'price-export',
  taskKind: 'download' | 'generate' | 'payroll',
): { section: string; title: string; subtitle: string } {
  if (workspaceView === 'approval') return {section:'业务审批',title:'蓝橙价格审批',subtitle:'筛选本人价格提审，跨页勾选后预览并批量同意当前节点'};
  if (workspaceView === 'price-export') return {section:'蓝橙价格',title:'待审每日价格导出',subtitle:'获取有权限站点的最新待审版本，生成骑手每日价格Excel'};
  if (workspaceView === 'history') {
    return {
      section: '任务与归档',
      title: '任务与产出中心',
      subtitle: '按四大系统筛选历史任务、巡检分项进度并打包领取产出文件',
    };
  }
  if (taskKind === 'generate') {
    return {
      section: '新建业务',
      title: '业务报表生成',
      subtitle: '选择目标业务报表，系统自动关联风神与蓝橙底层资料生成成品表',
    };
  }
  if (taskKind === 'payroll') {
    return {
      section: '新建业务',
      title: '兼职薪资结算',
      subtitle: '上传申请表，自动识别范围并准备资料、核算，完成后下载结果',
    };
  }
  return {
    section: '新建业务',
    title: '资料下载采集',
    subtitle: '风神按城市与账期采集，蓝橙全量交付，白泽员工原表独立下载；小象手动上传',
  };
}

export function getPayrollSidebarBadge(
  status?: string,
  isRunning?: boolean,
): { label: string; tone: 'active' | 'warn' | 'ready' | 'done' } | null {
  if (isRunning || status === 'calculating' || status === 'preparing') {
    return { label: '核算中', tone: 'active' };
  }
  if (status === 'pending_download' || status === 'waiting_materials') {
    return { label: '待补齐', tone: 'warn' };
  }
  if (status === 'ready') {
    return { label: '待核算', tone: 'ready' };
  }
  if (status === 'calculated') {
    return { label: '已出表', tone: 'done' };
  }
  return null;
}


