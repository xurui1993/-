import { TaskFlowSteps } from './TaskFlowSteps';
import { recoverySummary } from '../lib/downloadCenterLogic';
import { readDownloadResponse, saveDownloadBlob, downloadOutput, downloadErrorMessage } from '../lib/outputDownload';
import { isBaize, isXiaoxiang, isRiderArchive, isGlobalDataset, datasetGroup,isMerchant,isMerchantSnapshot,toggleDownloadDataset } from '../lib/downloadCenterLogic';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AlertCircle, CloudDownload, Download, KeyRound, Loader2, RefreshCw, Square, XCircle, FileSpreadsheet, Calculator } from 'lucide-react';
import { DownloadAccountPanel } from './DownloadAccountPanel';
import type { FengshenAuthStatus } from './FengshenLoginModal';
import { itemKey, phaseLabel, recoverable, retainAttempt, selectionKey, isLanorange } from '../lib/downloadCenterLogic';
import type { CreateSelection, DownloadUser, ItemSelection, Recovery, RequestAttempt } from '../lib/downloadCenterLogic';
import { WorkbenchDrawer } from './WorkbenchDrawer';
import { DownloadRecords } from './DownloadRecords';
import { isGenerator, inferTaskKind } from '../lib/taskCatalog';
import { DOWNLOAD_PLATFORMS,moduleAcceptsDataset,type DownloadPlatform,type RecordModule } from '../lib/downloadModules';
import {
  BUILTIN_DOWNLOAD_SCENARIOS,
  computeBillingPeriodRange,
  GENERATION_REPORT_CARDS,
  SYSTEM_META,
  type BillingPeriodPreset,
  type BuiltinScenarioPreset,
} from '../lib/workbench';

interface DownloadOptions {
  generators?: {id: string; label: string; scope: 'city_month' | 'all'; description: string; sources: string[]}[];
  cities: { name: string; id: string; disabled?: boolean; note?: string }[];
  cities_source?: 'fengshen' | 'config';
  cities_updated_at?: string;
  datasets: { id: string; label: string; group?: string; scope?: string }[];
  timezone: string;
  order_window_days: number;
  archive_root?: string;
  archive_naming_version?: string | number;
}

interface DownloadFile {
  artifact_role?: 'summary';
  id: string;
  name: string;
  city: string;
  dataset: string;
  start: string;
  end: string;
  bytes: number;
}

interface DownloadItem extends ItemSelection {
  status: string; error?: string; phase?: string; phase_since?: string;
  failure_phase?: string; submission_state?: 'not_submitted' | 'submitted' | 'unknown'; recovery?: Recovery;
}
const ORDER_TIMING_LABELS: Record<string, string> = {
  platform_poll_wait_seconds: '等待平台生成（轮询间隔）', source_download_seconds: '下载原始文件',
  source_read_seconds: '读取原始文件', source_validate_seconds: '校验来源资料',
  cache_read_seconds: '读取历史缓存', cache_write_seconds: '保存历史缓存',
  spool_write_seconds: '写入预处理资料', spool_read_seconds: '读取预处理资料',
  merge_seconds: '合并与重复检查', penalty_clean_seconds: '整理奖惩数据',
  classification_seconds: '问题单分类', summary_seconds: '生成问题单汇总',
  finalize_seconds: '本地汇总处理', csv_write_seconds: '写入结果文件',
};

interface PerformanceReport {
  order_pipelines?: {collection_seconds?: number; parser_seconds?: number; finalize_seconds?: number; timings?: Record<string, number>}[];
  elapsed_seconds?: number; total_seconds?: number; queued_seconds?: number; summary_seconds?: number;
  sampled_process_peak_rss_bytes?: number;
  stages?: Record<string, {seconds: number; calls: number}>;
  source_cache?: {hits: number; misses: number; retained_bytes: number; spill_files?: number; spill_bytes?: number};
  scheduler?: {collection_released_before_local_work: boolean; local_queue_seconds: number};
  generators?: {name: string; scope?: {city: string; month: string}; elapsed_seconds: number; stages: Record<string, {seconds: number; calls: number}>}[];
}
interface DownloadRun {
  performance?: PerformanceReport;
  lanorange_by_city?: boolean;
  lanorange_full_delivery?: boolean;
  refresh_history?: boolean;
  include_separation?: boolean;
  order_progress?: { batches?: number; batch?: number; obtained?: number; downloaded?: number; processed?: number;
    cached_days?: number; download_bytes?: number; processed_rows?: number; elapsed_seconds?: number; stage?: string };
  summary_progress?: { stage?: 'merging' | 'completed' | 'failed'; current?: number; total?: number; city?: string; month?: string };
  id: string;
  status: string;
  created_at: string;
  start: string;
  end: string;
  cities: string[];
  datasets: string[];
  progress: number;
  summary?: string | { total?: number; completed?: number; success?: number; error?: number; cancelled?: number; files?: number };
  error?: string;
  logs?: { time: string; message: string }[];
  items?: DownloadItem[];
  files?: DownloadFile[];
  recovery_of?: string;
  archive_relative_dir?: string;
  archive_code?: string;
  archive_version?: string | number;
  retry_of?: string;
  phase?: string;
  phase_since?: string;
  last_activity_at?: string;
  queue_position?: number;
  queue_wait_reason?: 'local_capacity' | 'collection_busy' | 'queued';
}

interface Props {
  platform?: DownloadPlatform;
  recordModule?: RecordModule;
  taskKind?: 'download' | 'generate';
  hideNavigation?: boolean;
  onTaskKindChange?: (kind: 'download' | 'generate') => void;
  onViewChange?: (view: 'create' | 'history') => void;
  onFormLock?: (locked: boolean) => void;
  onOpenPayroll?: (id: string) => void;
  onNavigateGenerate?: (cities: string[], start: string, end: string) => void;
  onNavigatePayroll?: (city?: string) => void;
  prefill?: {
    cities?: string[];
    start?: string;
    end?: string;
    taskKind?: 'download' | 'generate';
    token?: number;
  } | null;
  embedded?: boolean;
  navigation?: { view: 'create' | 'history'; version: number };
  apiFetch: (url: string, options?: RequestInit) => Promise<Response>;
  workspaceId: string;
  onOpenFengshenLogin?: (accountId?: string) => void;
  onAccountChange?: (accountId?: string) => void;
  onActiveCountChange?: (count: number) => void;
  fengshenAuthStatus?: FengshenAuthStatus | null;
}

const API_ROOT = '/api/fengshen-downloads';
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const DATASET_LABELS: Record<string, string> = {
  invitation_records:'邀请记录（全量）',attendance_detail:'骑手出勤明细',baize_employees: '白泽员工资料（全量）', rider_daily: '日维度骑手分析（小象灯塔）', rider_archive: '骑手档案（小象灯塔）', detail_orders: '配送订单明细（小象灯塔）', detail_kesu: '配送客诉明细（小象灯塔）', detail_reviews: '配送评价明细（小象灯塔）', delivery_fee: '配送费', penalty: '违规扣款', rider_monthly: '风神骑手月度 UB 账单',
  receive_account: '骑手风神绑定', rider_detail: '骑手数据明细', rider_info: '骑手信息导出', fraud: '欺诈单', problem: '问题单',
  payment_binding: '骑手支付绑定（生成表）', goods_rent: '物资租用登记',
  abnormal_followup: '异常骑手跟进（生成表）',
  abnormal_riders: '异常骑手整理（生成表）',
  lanorange_summary: '蓝橙资料汇总',
};
const MONTHLY_DATASETS = new Set(['rider_monthly', 'receive_account']);
const SNAPSHOT_DATASETS = new Set(['rider_info', 'goods_rent']);
const TERMINAL_STATUSES = new Set(['success', 'succeeded', 'completed', 'complete', 'partial', 'partial_failed', 'partial_failure', 'partially_completed', 'error', 'failed', 'cancelled', 'canceled', 'interrupted', 'aborted']);

function canRecoverDetail(run: DownloadRun | null) {
  return !!run && !run.recovery_of && run.cities?.length === 1
    && !run.items?.some(item => !!item.recovery)
    && ['error', 'partial'].includes(run.status.toLowerCase())
    && !!run.items?.some(item => item.dataset === 'rider_detail' && item.status.toLowerCase() !== 'success');
}

function readAttempt<T>(key: string): RequestAttempt<T> | null {
  try { const value = JSON.parse(sessionStorage.getItem(key) || 'null'); return value?.request_id && value?.payload ? value : null; }
  catch { return null; }
}
function storeAttempt(key: string, value: unknown) {
  try { if (value) sessionStorage.setItem(key, JSON.stringify(value)); else sessionStorage.removeItem(key); } catch {}
}
class DownloadRequestError extends Error {
  constructor(message: string, public status: number) { super(message); }
}

function statusInfo(status: string) {
  const normalized = (status || '').toLowerCase();
  if (['success', 'succeeded', 'completed', 'complete'].includes(normalized)) return { label: '已完成', color: 'text-emerald-700 bg-emerald-50 border border-emerald-200' };
  if (['partial', 'partial_failed', 'partial_failure', 'partially_completed'].includes(normalized)) return { label: '部分失败', color: 'text-amber-700 bg-amber-50 border border-amber-200' };
  if (['waiting_login', 'waiting_for_login', 'login_required', 'waiting_auth'].includes(normalized)) return { label: '等待登录', color: 'text-amber-700 bg-amber-50 border border-amber-200' };
  if (['queued', 'pending', 'waiting'].includes(normalized)) return { label: '排队中', color: 'text-slate-600 bg-slate-100 border border-slate-200' };
  if (['error', 'failed'].includes(normalized)) return { label: '失败', color: 'text-rose-700 bg-rose-50 border border-rose-200' };
  if (['cancelled', 'canceled'].includes(normalized)) return { label: '已取消', color: 'text-slate-600 bg-slate-100 border border-slate-200' };
  if (['interrupted', 'aborted'].includes(normalized)) return { label: '已中断', color: 'text-amber-700 bg-amber-50 border border-amber-200' };
  if (['cancelling', 'canceling'].includes(normalized)) return { label: '正在停止', color: 'text-slate-600 bg-slate-100 border border-slate-200' };
  if (normalized === 'empty' || normalized === 'no_data') return { label: '无记录', color: 'text-slate-600 bg-slate-100 border border-slate-200' };
  return { label: normalized === 'running' || normalized === 'downloading' ? '下载中' : '处理中', color: 'text-sky-700 bg-sky-50 border border-sky-200' };
}

function shanghaiToday() {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date());
  const value = (type: string) => parts.find(part => part.type === type)?.value || '';
  return `${value('year')}-${value('month')}-${value('day')}`;
}

function coveredMonths(start: string, end: string) {
  if (!DATE_PATTERN.test(start) || !DATE_PATTERN.test(end) || start > end) return [];
  const [startYear, startMonth] = start.split('-').map(Number);
  const [endYear, endMonth] = end.split('-').map(Number);
  const first = startYear * 12 + startMonth - 1;
  const last = endYear * 12 + endMonth - 1;
  if (last - first > 1200) return [];
  return Array.from({ length: last - first + 1 }, (_, index) => {
    const month = first + index;
    return `${Math.floor(month / 12)}年${String(month % 12 + 1).padStart(2, '0')}月`;
  });
}

function displayTime(value?: string) {
  if (!value) return '';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', hour12: false });
}

function formatSize(bytes: number) {
  if (!Number.isFinite(bytes) || bytes < 0) return '';
  return bytes >= 1024 * 1024 ? `${(bytes / (1024 * 1024)).toFixed(1)} MB` : `${Math.max(1, Math.ceil(bytes / 1024))} KB`;
}

function saveBlobToDevice(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename.replace(/[\\/:*?"<>|]/g, '_');
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

export function FengshenDownloadCenter(props: Props) {
  return <DownloadAccountPanel apiFetch={props.apiFetch} onAccountChange={props.onAccountChange}>{(user, authenticatedFetch) => <AuthorizedDownloadCenter key={user.id} {...props} apiFetch={authenticatedFetch} user={user} />}</DownloadAccountPanel>;
}

function AuthorizedDownloadCenter({ apiFetch, workspaceId, onOpenFengshenLogin, onActiveCountChange, fengshenAuthStatus, user, embedded, navigation, taskKind = 'download', platform,recordModule,hideNavigation, onTaskKindChange, onViewChange, onFormLock, onOpenPayroll, onNavigateGenerate, onNavigatePayroll, prefill }: Props & { user: DownloadUser }) {
  const apiRef = useRef(apiFetch);
  apiRef.current = apiFetch;
  const [options, setOptions] = useState<DownloadOptions | null>(null);
  const [optionsError, setOptionsError] = useState('');
  const [optionsLoading, setOptionsLoading] = useState(false);
  const [optionVersion, setOptionVersion] = useState(0);
  const [cities, setCities] = useState<string[]>([]);
  const [datasets, setDatasets] = useState<string[]>(() => taskKind === 'generate' ? ['payment_binding'] : []);
  const categorySelections = useRef<Record<string, string[]>>({download: [], generate: ['payment_binding'],baize:['baize_employees'],xiaoxiang:['rider_daily']});
  const selectionScope=taskKind==='generate'?'generate':platform||'download';
  const previousKind = useRef(selectionScope);
  const moduleDataset=(id:string)=>taskKind==='generate'?isGenerator(id):!isGenerator(id)&&(!platform||moduleAcceptsDataset(id,platform));
  const visibleDatasets=options?.datasets.filter(value=>moduleDataset(value.id))||[];
  const [start, setStart] = useState(() => `${shanghaiToday().slice(0, 7)}-01`);
  const [end, setEnd] = useState(shanghaiToday);
  const [refreshHistory, setRefreshHistory] = useState(false);
  const [includeSeparation, setIncludeSeparation] = useState(false);
  const [runs, setRuns] = useState<DownloadRun[]>([]);
  const [cityPickerOpen, setCityPickerOpen] = useState(false);
  const [citySearch, setCitySearch] = useState('');
  const [view, setView] = useState<'create' | 'history'>('create');
  useEffect(() => { if (navigation) setView(navigation.view); }, [navigation?.version]);

  useEffect(() => {
    if (!prefill || !prefill.token) return;
    if (prefill.cities && prefill.cities.length) {
      setCities(prefill.cities);
    }
    if (prefill.start) setStart(prefill.start);
    if (prefill.end) setEnd(prefill.end);
    if (prefill.taskKind && onTaskKindChange) onTaskKindChange(prefill.taskKind);
  }, [prefill?.token]);
  const presetsKey = `download-presets:${user.id}`;
  const [presets, setPresets] = useState<{ name: string; cities: string[]; datasets: string[] }[]>(() => {
    try { const parsed = JSON.parse(localStorage.getItem(presetsKey) || '[]'); return Array.isArray(parsed) ? parsed.filter(item => Array.isArray(item?.cities) && Array.isArray(item?.datasets)) : []; } catch { return []; }
  });
  const [presetInputOpen, setPresetInputOpen] = useState(false);
  const [presetDraft, setPresetDraft] = useState('');
  const [systemFilter, setSystemFilter] = useState<'all' | 'fengshen' | 'lanorange' | 'baize' | 'xiaoxiang'>('all');

  const lastTaskKey = `download-last-task:${user.id}:${workspaceId}`;
  const [selectedId, setSelectedId] = useState(() => { try { return localStorage.getItem(lastTaskKey) || ''; } catch { return ''; } });
  useEffect(() => { try { if (selectedId) localStorage.setItem(lastTaskKey, selectedId); } catch {} }, [lastTaskKey, selectedId]);
  const selectedIdRef = useRef(selectedId);
  const [selectedRun, setSelectedRun] = useState<DownloadRun | null>(null);
  const [scopeReview, setScopeReview] = useState<CreateSelection | null>(null);
  useEffect(() => {
    const changed = () => setScopeReview(null);
    window.addEventListener('platform-auth:changed', changed);
    return () => window.removeEventListener('platform-auth:changed', changed);
  }, []);
  const [creating, setCreating] = useState(false);
  const creatingRef = useRef(false);
  const createStorageKey = `download-create-attempt:${user.id}`;
  const retryStorageKey = `download-retry-attempt:${user.id}`;
  const createAttempt = useRef(readAttempt<CreateSelection>(createStorageKey));
  const retryAttempt = useRef(readAttempt<{ runId: string; items: ItemSelection[] }>(retryStorageKey));
  const [uncertainCreate, setUncertainCreate] = useState(!!createAttempt.current);
  useEffect(() => { onFormLock?.(uncertainCreate || creating); }, [uncertainCreate, creating]);
  useEffect(() => { onViewChange?.(view); }, [view]);
  useEffect(() => {
    if (previousKind.current === selectionScope || createAttempt.current) return;
    const previous = previousKind.current; previousKind.current = selectionScope;
    setDatasets(values => {
      categorySelections.current[previous] = values;
      const saved = categorySelections.current[selectionScope]||[];
      return taskKind === 'download' ? saved.filter(moduleDataset) : [saved.find(isGenerator) || 'payment_binding'];
    });
    setDuplicateApproval('');
  }, [selectionScope]);
  useEffect(() => {
    const previous = createAttempt.current?.payload;
    if (previous) { setCities(previous.cities); setDatasets(previous.datasets); setStart(previous.start); setEnd(previous.end); setRefreshHistory(!!previous.refresh_history); setIncludeSeparation(!!previous.include_separation); }
  }, []);
  const [uncertainRetry, setUncertainRetry] = useState(!!retryAttempt.current);
  const [retryPending, setRetryPending] = useState(false);
  const retryPendingRef = useRef(false);
  const [retryKeys, setRetryKeys] = useState<string[]>([]);
  const [duplicateApproval, setDuplicateApproval] = useState('');
  const [resumingRunId, setResumingRunId] = useState('');
  const resumingRef = useRef(false);
  const [recoveryError, setRecoveryError] = useState<{ runId: string; message: string } | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const [downloadingSummaryId, setDownloadingSummaryId] = useState('');
  const downloadingSummaryRef = useRef(false);
  const downloadControllers = useRef(new Set<AbortController>());
  const attemptOpenController = useRef<AbortController | null>(null);
  const [requestError, setRequestError] = useState('');
  const [pollError, setPollError] = useState('');
  const [loadingHistory, setLoadingHistory] = useState(true);
  const [now, setNow] = useState(Date.now);
  useEffect(() => { const timer = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(timer); }, []);
  const refreshRef = useRef<() => Promise<void>>(async () => {});
  const prevRunStatuses = useRef<Map<string, string>>(new Map());

  useEffect(() => () => {
    attemptOpenController.current?.abort();
    for (const controller of downloadControllers.current) controller.abort();
    downloadControllers.current.clear();
  }, [workspaceId]);

  const getJson = useCallback(async (url: string, init: RequestInit = {}) => {
    const response = await apiRef.current(url, { ...init, signal: init.signal || AbortSignal.timeout(15000) });
    const data = await response.json().catch(() => null);
    if (!response.ok || !data || data.success === false) {
      const reason = data?.error || data?.detail || data?.message;
      throw new DownloadRequestError(typeof reason === 'string' ? reason : '下载服务暂不可用，请稍后重试', response.status);
    }
    return data;
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    setOptionsError('');
    setOptionsLoading(true);
    // First paint uses cached options; explicit refresh synchronizes the platform.
    void getJson(`${API_ROOT}/options?${optionVersion ? 'refresh=1' : 'cached=1'}`, { signal: AbortSignal.any([controller.signal, AbortSignal.timeout(20000)]) })
      .then(data => {
        if (controller.signal.aborted) return;
        if (!Array.isArray(data.cities) || !Array.isArray(data.datasets)) throw new Error('下载选项暂不可用，请重试');
        setOptions(data);
        setCities(previous => previous.filter(city => data.cities.some((item: { name: string; disabled?: boolean }) => item.name === city && !item.disabled)));
        setDatasets(previous => previous.filter(dataset => data.datasets.some((item: { id: string }) => item.id === dataset)));
      })
      .catch(error => { if (!controller.signal.aborted) setOptionsError(error instanceof Error ? error.message : '无法加载下载选项'); })
      .finally(() => { if (!controller.signal.aborted) setOptionsLoading(false); });
    return () => controller.abort();
  }, [getJson, workspaceId, optionVersion]);

  // 任务从运行中翻转为终态时发一次系统通知（需浏览器通知权限）
  const notifyFinishedRuns = (nextRuns: DownloadRun[]) => {
    const previous = prevRunStatuses.current;
    for (const run of nextRuns) {
      const before = previous.get(run.id);
      if (!before || TERMINAL_STATUSES.has(before.toLowerCase()) || !TERMINAL_STATUSES.has(run.status.toLowerCase())) continue;
      const normalized = run.status.toLowerCase();
      const title = ['success', 'succeeded', 'completed', 'complete'].includes(normalized) ? '下载任务已完成'
        : normalized.includes('partial') ? '下载任务部分完成（含失败项）' : '下载任务已结束';
      const scope = run.cities.length > 2 ? `${run.cities.length} 个城市` : (run.cities.join('、') || '蓝橙全量');
      const body = `${scope} · ${run.datasets.length} 类资料${run.files?.length ? ` · ${run.files.length} 个文件` : ''}`;
      if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
        try { new Notification(title, { body }); } catch { /* 通知失败不影响轮询 */ }
      }
    }
    prevRunStatuses.current = new Map(nextRuns.map(run => [run.id, run.status]));
  };

  useEffect(() => {
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout> | undefined;
    let busy = false;
    let polling = false;
    const snapshot = async () => {
      if (busy || controller.signal.aborted || document.visibilityState !== 'visible') return;
      busy = true;
      try {
        const signal = AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]);
        const data = await getJson(`${API_ROOT}/runs`, { signal });
        if (controller.signal.aborted) return;
        const nextRuns: DownloadRun[] = Array.isArray(data.runs) ? data.runs : [];
        setRuns(nextRuns);
        notifyFinishedRuns(nextRuns);
        let id = selectedIdRef.current;
        if ((!id || !nextRuns.some(run => run.id === id)) && nextRuns.length) {
          id = nextRuns[0].id;
          selectedIdRef.current = id;
          setSelectedId(id);
        }
        if (id) {
          const detail = await getJson(`${API_ROOT}/runs/${encodeURIComponent(id)}`, { signal });
          if (!controller.signal.aborted && selectedIdRef.current === id) setSelectedRun(detail.run || null);
        }
        if (!controller.signal.aborted) setPollError('');
      } catch (error) {
        if (!controller.signal.aborted) setPollError(error instanceof Error ? error.message : '暂时无法更新下载记录');
      } finally {
        busy = false;
        if (!controller.signal.aborted) setLoadingHistory(false);
      }
    };
    refreshRef.current = snapshot;
    const tick = async () => {
      if (polling) return;
      polling = true;
      try { await snapshot(); }
      finally {
        polling = false;
        if (!controller.signal.aborted && document.visibilityState === 'visible') timer = setTimeout(tick, 2000);
      }
    };
    const onVisibility = () => {
      clearTimeout(timer);
      if (document.visibilityState === 'visible') void tick();
    };
    void tick();
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      controller.abort();
      clearTimeout(timer);
      document.removeEventListener('visibilitychange', onVisibility);
      refreshRef.current = async () => {};
    };
  }, [getJson, workspaceId]);

  const datasetLabel = (id: string) => options?.datasets.find(dataset => dataset.id === id)?.label || DATASET_LABELS[id] || id;
  const citySyncedAt = options?.cities_updated_at ? new Date(options.cities_updated_at) : null;
  const citySourceLabel = options?.cities_source === 'fengshen'
    ? `风神同步${citySyncedAt && !Number.isNaN(citySyncedAt.getTime()) ? ` · ${citySyncedAt.toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}` : ''}`
    : '本地配置';
  const toggle = (value: string, values: string[], setter: (next: string[]) => void) => setter(values.includes(value) ? values.filter(item => item !== value) : [...values, value]);
  const validDates = DATE_PATTERN.test(start) && DATE_PATTERN.test(end) && start <= end;
  const baizeOnly = datasets.length === 1 && isBaize(datasets[0]);
  const xiaoxiangOnly = datasets.length === 1 && isXiaoxiang(datasets[0]);
  const archiveOnly = xiaoxiangOnly && isRiderArchive(datasets[0]);
  const xiaoxiangDated = xiaoxiangOnly && !archiveOnly;
  const yesterday = new Date(shanghaiToday() + 'T00:00:00Z'); yesterday.setUTCDate(yesterday.getUTCDate() - 1);
  const dailyDate = yesterday.toISOString().slice(0, 10);
  const blueOnly = datasets.length > 0 && datasets.every(isGlobalDataset);
  const merchantOnly=datasets.length>0&&datasets.every(isMerchant),merchantSnapshotOnly=merchantOnly&&!datasets.includes('attendance_detail');
  const noCity=blueOnly||xiaoxiangOnly,noDate=blueOnly||merchantSnapshotOnly||archiveOnly;
  const attendanceDateMax=new Date(shanghaiToday()+'T00:00:00Z');attendanceDateMax.setUTCDate(attendanceDateMax.getUTCDate()-1);const attendanceLast=attendanceDateMax.toISOString().slice(0,10);
  const attendanceDateMin=new Date(shanghaiToday()+'T00:00:00Z');attendanceDateMin.setUTCDate(attendanceDateMin.getUTCDate()-90);const attendanceFirst=attendanceDateMin.toISOString().slice(0,10);
  const xiaoxiangDateMin=new Date(`${dailyDate}T00:00:00Z`);xiaoxiangDateMin.setUTCDate(xiaoxiangDateMin.getUTCDate()-30);const xiaoxiangFirst=xiaoxiangDateMin.toISOString().slice(0,10);
  const xiaoxiangSpanDays=validDates?Math.round((Date.parse(`${end}T00:00:00Z`)-Date.parse(`${start}T00:00:00Z`))/86400000)+1:0;
  const xiaoxiangDateValid=validDates&&end<=dailyDate&&xiaoxiangSpanDays<=31;
  useEffect(()=>{
    if(!xiaoxiangOnly||archiveOnly)return;
    if(end>dailyDate||start>dailyDate){setStart(dailyDate);setEnd(dailyDate);}
  },[xiaoxiangOnly,archiveOnly,dailyDate]);
  const merchantDateValid=merchantSnapshotOnly||(validDates&&start>=attendanceFirst&&end<=attendanceLast);
  const invalidBaizeMix = datasets.some(isBaize) && !baizeOnly;
  const invalidXiaoxiangMix = datasets.some(isXiaoxiang) && !xiaoxiangOnly;
  const selectableCities = options?.cities.filter(city => !city.disabled) ?? [];
  const invalidMerchantMix=datasets.some(isMerchant)&&!merchantOnly;
  const canSubmit = datasets.every(moduleDataset) && !invalidBaizeMix && !invalidXiaoxiangMix && !invalidMerchantMix && datasets.length > 0 && (merchantOnly?(cities.length>0&&merchantDateValid):(archiveOnly || blueOnly || (xiaoxiangDated && xiaoxiangDateValid) || (cities.length > 0 && validDates)));
  const monthlyDatasets = datasets.filter(dataset => MONTHLY_DATASETS.has(dataset));
  const periodDatasets = datasets.filter(dataset => !isLanorange(dataset) && !MONTHLY_DATASETS.has(dataset) && !SNAPSHOT_DATASETS.has(dataset) && !['payment_binding', 'abnormal_followup'].includes(dataset));
  const followupDatasets = ['payment_binding', 'abnormal_followup'].filter(id => datasets.includes(id));
  const monthPreview = monthlyDatasets.length || followupDatasets.length ? coveredMonths(start, end) : [];
  const orderWindowDays = options?.order_window_days || 60;
  const earliestOrderDate = new Date(`${shanghaiToday()}T00:00:00Z`);
  earliestOrderDate.setUTCDate(earliestOrderDate.getUTCDate() - orderWindowDays + 1);
  const earliestOrder = earliestOrderDate.toISOString().slice(0, 10);
  const orderWindowWarning = datasets.some(dataset => ['fraud', 'problem'].includes(dataset)) && validDates && (start < earliestOrder || end > shanghaiToday());
  const currentSelection = { task_kind: taskKind, ...(taskKind === 'generate' ? { generation_target: datasets[0] } : {}), cities: blueOnly || xiaoxiangOnly ? ['全部城市'] : cities, datasets, ...(datasets.some(isLanorange) ? {lanorange_full_delivery:true} : {}),
    start: archiveOnly ? shanghaiToday() : xiaoxiangDated ? start : blueOnly||merchantSnapshotOnly ? shanghaiToday() : start, end: archiveOnly ? shanghaiToday() : xiaoxiangDated ? end : blueOnly||merchantSnapshotOnly ? shanghaiToday() : end,
    ...(refreshHistory && datasets.some(dataset => ['fraud', 'problem'].includes(dataset)) ? { refresh_history: true } : {}),
    ...(merchantOnly?{merchant_by_city:true}:{}), ...(includeSeparation && !noCity && !merchantOnly ? { include_separation: true } : {}) };
  const currentSelectionKey = selectionKey(currentSelection);
  const matchingRun = runs.find(run => !TERMINAL_STATUSES.has(run.status) && selectionKey(run) === currentSelectionKey)
    || (!followupDatasets.length && !datasets.some(isLanorange) && !merchantOnly ? runs.find(run => selectionKey(run) === currentSelectionKey && !!run.files?.length) : undefined);
  const completedMatch = matchingRun && TERMINAL_STATUSES.has(matchingRun.status) && !!matchingRun.files?.length;
  const formLocked = creating || uncertainCreate;

  const selectRun = (run: DownloadRun) => {
    setView('history');
    selectedIdRef.current = run.id;
    setSelectedId(run.id);
    setSelectedRun(run);
    setRetryKeys([]);
    setRequestError('');
    void refreshRef.current();
  };

  const savePreset = (customName?: string) => {
    const rawName = typeof customName === 'string' ? customName : presetDraft;
    const trimmed = rawName.trim();
    if (!trimmed) return;
    const next = [...presets.filter(preset => preset.name !== trimmed), { name: trimmed, cities: [...cities], datasets: [...datasets] }].slice(-12);
    setPresets(next);
    setPresetDraft('');
    setPresetInputOpen(false);
    try { localStorage.setItem(presetsKey, JSON.stringify(next)); } catch { /* 存储不可用时仅保留在内存 */ }
  };
  const applyPreset = (preset: { name: string; cities: string[]; datasets: string[] }) => {
    if (preset.datasets.some(isGenerator) && preset.datasets.length !== 1) { setRequestError('此预设包含旧版混合选择，请按任务类型分别新建。'); return; }
    categorySelections.current[taskKind] = datasets;
    categorySelections.current[inferTaskKind(preset.datasets)] = preset.datasets;
    onTaskKindChange?.(inferTaskKind(preset.datasets));
    setCities(preset.cities.filter(city => !options || options.cities.some(item => item.name === city && !item.disabled)));
    setDatasets(preset.datasets.filter(id => !options || options.datasets.some(item => item.id === id)));
    setDuplicateApproval('');
  };
  const removePreset = (name: string) => {
    const next = presets.filter(preset => preset.name !== name);
    setPresets(next);
    try { localStorage.setItem(presetsKey, JSON.stringify(next)); } catch { /* 同上 */ }
  };
  const applyBuiltinScenario = (scenario: BuiltinScenarioPreset) => {
    if (formLocked) return;
    const validIds = scenario.datasets.filter(id => !options || options.datasets.some(item => item.id === id));
    categorySelections.current[taskKind] = datasets;
    categorySelections.current.download = validIds;
    onTaskKindChange?.('download');
    setDatasets(validIds);
    setDuplicateApproval('');
    setRequestError('');
  };
  const applyBillingPeriod = (preset: BillingPeriodPreset) => {
    if (formLocked) return;
    const range = computeBillingPeriodRange(preset, shanghaiToday());
    setStart(merchantOnly&&range.start<attendanceFirst?attendanceFirst:range.start);
    setEnd(merchantOnly&&range.end>attendanceLast?attendanceLast:range.end);
    setDuplicateApproval('');
  };

  // 用历史任务的城市/资料/日期预填新建表单
  const prefillFromRun = (run: DownloadRun) => {
    if (run.datasets.some(isGenerator) && (run.datasets.length !== 1 || !isGenerator(run.datasets[0]))) {
      setRequestError('此记录包含旧版混合选择，请按资料下载或业务表生成分别新建。'); return;
    }
    categorySelections.current[taskKind] = datasets;
    categorySelections.current[inferTaskKind(run.datasets)] = run.datasets;
    onTaskKindChange?.(inferTaskKind(run.datasets));
    setCities(run.cities.filter(city => city !== '全部城市' && (!options || options.cities.some(item => item.name === city && !item.disabled))));
    setDatasets(run.datasets.filter(id => !options || options.datasets.some(item => item.id === id)));
    if (!run.datasets.every(isLanorange) && DATE_PATTERN.test(run.start) && DATE_PATTERN.test(run.end)) { setStart(run.start); setEnd(run.end); }
    setRefreshHistory(false);
    setIncludeSeparation(false);
    setDuplicateApproval('');
    setRequestError('');
    setView('create');
  };

  const startDownload = async (confirmedKey?: string) => {
    if (creatingRef.current || !options || (!createAttempt.current && !canSubmit)) return;
    if (!createAttempt.current && matchingRun && !TERMINAL_STATUSES.has(matchingRun.status)) { selectRun(matchingRun); return; }
    if (!createAttempt.current && completedMatch && duplicateApproval !== currentSelectionKey) { selectRun(matchingRun!); return; }
    if (!createAttempt.current && confirmedKey !== currentSelectionKey) { setScopeReview(JSON.parse(JSON.stringify(currentSelection))); return; }
    createAttempt.current = retainAttempt(createAttempt.current, currentSelection);
    storeAttempt(createStorageKey, createAttempt.current);
    creatingRef.current = true;
    setCreating(true);
    setRequestError('');
    if (typeof Notification !== 'undefined' && Notification.permission === 'default') void Notification.requestPermission();
    try {
      const data = await getJson(`${API_ROOT}/runs`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...createAttempt.current.payload, request_id: createAttempt.current.request_id }),
      });
      if (!data.run?.id) throw new Error('未取得下载任务，请刷新记录确认后再试');
      const run: DownloadRun = data.run;
      createAttempt.current = null; storeAttempt(createStorageKey, null); setUncertainCreate(false); setDuplicateApproval('');
      setRuns(previous => [run, ...previous.filter(item => item.id !== run.id)]);
      selectedIdRef.current = run.id;
      setSelectedId(run.id);
      setSelectedRun(run);
      setView('history');
      void refreshRef.current();
    } catch (error) {
      const rejected = error instanceof DownloadRequestError && [400, 401, 403, 404, 409, 415, 422].includes(error.status);
      if (rejected) { createAttempt.current = null; storeAttempt(createStorageKey, null); }
      setUncertainCreate(!rejected);
      setRequestError(rejected ? error.message : '下载请求结果尚未确认。请使用“重新确认原请求”，系统会沿用同一请求编号，不会盲目新建任务。');
    } finally {
      creatingRef.current = false;
      setCreating(false);
    }
  };

  const retrySelected = async (only?: ItemSelection) => {
    if (retryPendingRef.current || (!retryAttempt.current && !selectedRun)) return;
    const selected = selectedRun?.items?.filter(item => (only ? itemKey(only) === itemKey(item) : retryKeys.includes(itemKey(item))) && recoverable(item)) || [];
    if (!retryAttempt.current && !selected.length) return;
    if (!retryAttempt.current) retryAttempt.current = retainAttempt(null, { runId: selectedRun!.id, items: selected.map(({ city, dataset, start, end }) => ({ city, dataset, start, end })) });
    storeAttempt(retryStorageKey, retryAttempt.current);
    retryPendingRef.current = true; setRetryPending(true); setRequestError('');
    try {
      const attempt = retryAttempt.current;
      const data = await getJson(`${API_ROOT}/runs/${encodeURIComponent(attempt.payload.runId)}/retry`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: attempt.payload.items, request_id: attempt.request_id }),
      });
      if (!data.run?.id) throw new Error('未取得分项处理任务');
      retryAttempt.current = null; storeAttempt(retryStorageKey, null); setUncertainRetry(false); setRetryKeys([]);
      setRuns(previous => [data.run, ...previous.filter(run => run.id !== data.run.id)]);
      selectRun(data.run);
    } catch (error) {
      const rejected = error instanceof DownloadRequestError && [400, 401, 403, 404, 409, 415, 422].includes(error.status);
      if (rejected) { retryAttempt.current = null; storeAttempt(retryStorageKey, null); }
      setUncertainRetry(!rejected);
      setRequestError(rejected ? error.message : '分项操作结果尚未确认，请重新确认原分项请求；不会更换请求编号或重新发起不明导出。');
    } finally { retryPendingRef.current = false; setRetryPending(false); }
  };

  const cancelDownload = async () => {
    if (!selectedRun || cancelling) return;
    const id = selectedRun.id;
    setCancelling(true);
    setRequestError('');
    try {
      const data = await getJson(`${API_ROOT}/runs/${encodeURIComponent(id)}/cancel`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}',
      });
      if (selectedIdRef.current === id && data.run) setSelectedRun(data.run);
      void refreshRef.current();
    } catch (error) {
      setRequestError(error instanceof Error ? error.message : '无法停止任务');
    } finally { setCancelling(false); }
  };

  const resumeDetail = async () => {
    if (resumingRef.current || !canRecoverDetail(selectedRun)) return;
    const id = selectedRun!.id;
    resumingRef.current = true;
    setResumingRunId(id);
    setRecoveryError(null);
    try {
      const data = await getJson(`${API_ROOT}/runs/${encodeURIComponent(id)}/resume-detail`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}',
      });
      if (!data.run?.id || data.run.id === id) throw new Error('恢复任务状态尚未确认，请刷新下载记录查看，不要重新发起导出');
      const run: DownloadRun = { ...data.run, recovery_of: data.run.recovery_of || id };
      setRuns(previous => [run, ...previous.filter(item => item.id !== run.id)]);
      selectedIdRef.current = run.id;
      setSelectedId(run.id);
      setSelectedRun(run);
      setView('history');
      void refreshRef.current();
    } catch (error) {
      const uncertain = error instanceof Error && ['TimeoutError', 'AbortError', 'TypeError'].includes(error.name);
      setRecoveryError({
        runId: id,
        message: uncertain ? '恢复请求结果尚未确认，请刷新下载记录查看，不要重新发起导出'
          : error instanceof Error ? error.message : '恢复未能启动，请查看下载记录，不要重新发起导出',
      });
    } finally {
      resumingRef.current = false;
      setResumingRunId('');
    }
  };

  const downloadSummary = async () => {
    if (!selectedRun || downloadingSummaryRef.current || !TERMINAL_STATUSES.has(selectedRun.status.toLowerCase())) return;
    const run = selectedRun;
    const controller = new AbortController();
    downloadControllers.current.add(controller);
    downloadingSummaryRef.current = true;
    setDownloadingSummaryId(run.id);
    setRequestError('');
    try {
      const response = await apiRef.current(`${API_ROOT}/runs/${encodeURIComponent(run.id)}/summary`, { signal: AbortSignal.any([controller.signal, AbortSignal.timeout(30000)]) });
      if (!response.ok) {
        const data = await response.json().catch(() => null);
        throw new Error(typeof data?.detail === 'string' ? data.detail : typeof data?.error === 'string' ? data.error : '下载说明暂不可用，请稍后重试');
      }
      const code = run.archive_code || run.id.slice(0, 6).toUpperCase();
      const blob = await readDownloadResponse(response, `下载说明_${code}.txt`);
      if (!controller.signal.aborted) saveBlobToDevice(blob, `下载说明_${code}.txt`);
    } catch (error) {
      if (!controller.signal.aborted) setRequestError(error instanceof Error ? error.message : '下载说明保存失败，请重试');
    } finally {
      downloadControllers.current.delete(controller);
      downloadingSummaryRef.current = false;
      setDownloadingSummaryId('');
    }
  };

  const [rawBusy, setRawBusy] = useState(false);
  const rawBusyRef = useRef(false);
  const downloadRawBundle = async () => {
    if (!selectedRun || rawBusyRef.current) return;
    rawBusyRef.current = true; setRawBusy(true);
    setRequestError('');
    try {
      const response = await apiRef.current(`${API_ROOT}/runs/${selectedRun.id}/raw-bundle`, { signal: AbortSignal.timeout(120000) });
      if (!response.ok) { const data = await response.json().catch(() => ({})); throw new Error(data.detail || '原始资料领取失败'); }
      saveDownloadBlob(await readDownloadResponse(response, `原始资料_${selectedRun.id.slice(0, 8)}.zip`), `原始资料_${selectedRun.id.slice(0, 8)}.zip`);
    } catch (error) { setRequestError(downloadErrorMessage(error)); }
    finally { rawBusyRef.current = false; setRawBusy(false); }
  };

  const [fileBusy, setFileBusy] = useState('');
  const fileBusyRef = useRef(false);
  const downloadFile = async (id: string, name: string) => {
    if (!selectedRun || fileBusyRef.current) return;
    fileBusyRef.current = true; setFileBusy(id); setRequestError('');
    try { await downloadOutput(`${API_ROOT}/runs/${selectedRun.id}/files/${id}`, workspaceId, name, apiRef.current); }
    catch (error) { setRequestError(error instanceof Error ? error.message : '文件领取失败，请重试'); }
    finally { fileBusyRef.current = false; setFileBusy(''); }
  };
  const panel = 'rounded-xl border border-slate-200 bg-white';
  const smallButton = 'inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed';
  const activeRun = selectedRun && !TERMINAL_STATUSES.has(selectedRun.status.toLowerCase());
  const waitingLogin = selectedRun && (selectedRun.phase === 'waiting_login' || ['waiting_login', 'waiting_for_login', 'login_required', 'waiting_auth'].includes(selectedRun.status.toLowerCase()));
  const selectedRecoverable = selectedRun?.items?.filter(recoverable) || [];
  const subitemCount = merchantOnly?cities.length*datasets.length:baizeOnly || xiaoxiangOnly ? 1 : datasets.filter(isLanorange).length + cities.length * (periodDatasets.length + followupDatasets.length * monthPreview.length + datasets.filter(value => SNAPSHOT_DATASETS.has(value)).length + monthlyDatasets.length * monthPreview.length);
  const submitHint = taskKind === 'generate'
    ? datasets[0] === 'abnormal_riders' ? '全部城市 · 全量资料 · 生成一份整理表'
      : !cities.length ? '请选择生成范围的城市' : !validDates ? '请选择有效日期' : `${cities.length} 个城市 · 按 ${monthPreview.length} 个月份生成`
    : merchantOnly?merchantSnapshotOnly?'所选城市商家全部邀请记录 · 全部分页 · 不筛选日期':merchantDateValid?'各城市商家全部站点 · 出勤按日期分段后合并领取':'出勤明细请选择最近90天内、早于今天的起止日期'
    : baizeOnly ? '白泽全量员工原表 · 一份文件 · 不参与兼职自动补齐'
    : xiaoxiangOnly ? (archiveOnly ? '小象灯塔骑手档案 · 全部站点当前快照 · 一份工作簿' : start===end ? `小象灯塔商配送看板 · ${start} 单日 · 一份工作簿` : `小象灯塔商配送看板 · ${start} 至 ${end}，共 ${xiaoxiangSpanDays} 天 · 合并一份工作簿`)
    : blueOnly
    ? `蓝橙全量 · ${datasets.length} 类资料，每类一个文件，无需选择城市和日期`
    : !datasets.length ? '请选择资料'
    : !cities.length ? '请选择城市'
    : !validDates ? '开始日期不能晚于结束日期'
    : `${cities.length} 个城市 · ${datasets.length} 类资料 · 共 ${subitemCount} 项`;
  const submitReady = !!uncertainCreate || canSubmit;
  const elapsed = (since?: string) => { const seconds = Math.max(0, Math.floor((now - new Date(since || "").getTime()) / 1000)); return Number.isFinite(seconds) ? seconds < 60 ? `${seconds} 秒` : `${Math.floor(seconds / 60)} 分 ${seconds % 60} 秒` : ""; };
  const progress = Math.max(0, Math.min(100, Number(selectedRun?.progress) || 0));
  const summaryDetail = selectedRun?.summary_progress;
  const summarizing = selectedRun?.phase === 'summarizing';
  const runStatusLabel = summarizing ? '汇总合并中' : selectedRun ? statusInfo(selectedRun.status).label : '';
  const summaryMonth = summaryDetail?.month ? `${Number(summaryDetail.month.slice(5))}月` : '';
  const summaryHint = !summarizing ? '' : summaryDetail?.stage === 'failed'
    ? '汇总合并未完成，城市文件已保留，请查看错误提示。'
    : `资料项已结束，正在生成多城市汇总${summaryMonth ? `（${summaryMonth}）` : ''}${summaryDetail?.total ? `：${summaryDetail.current || 0}/${summaryDetail.total} 个城市` : ''}${summaryDetail?.city ? ` · 正在合并 ${summaryDetail.city}` : ''}。`;
  const summary = selectedRun?.summary && typeof selectedRun.summary === 'object' ? selectedRun.summary : null;

  const runningCount = runs.filter(run => !TERMINAL_STATUSES.has(run.status.toLowerCase())).length;
  useEffect(() => { onActiveCountChange?.(runningCount); }, [runningCount, onActiveCountChange]);
  const failedItems = selectedRun?.items?.filter(item => ['error', 'failed', 'interrupted'].includes(item.status)) || [];
  const choiceStyle = (selected: boolean) => `flex min-w-0 cursor-pointer items-center gap-2 rounded-lg border px-3 py-2.5 text-sm ${selected ? 'border-sky-600 bg-sky-50 text-sky-600 font-medium' : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50'}`;
  const primaryButton = 'inline-flex items-center justify-center gap-2 rounded-lg bg-sky-700 px-5 py-3 text-sm font-semibold text-white hover:bg-sky-800 disabled:opacity-40 disabled:cursor-not-allowed';
  const fieldStyle = 'min-w-0 w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 [color-scheme:light]';

  return (
    <div className="relative z-10 mx-auto flex w-full max-w-6xl min-w-0 flex-col gap-5 pb-5 text-slate-900">
      {!embedded && <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2.5 text-xl font-semibold"><CloudDownload size={23} className="text-sky-700" />下载中心</h1>
          <p className="mt-1.5 text-sm text-slate-500">新建下载、跟踪进度、浏览产出文件；风神资料按城市和日期，蓝橙资料统一交付。</p>
        </div>
      </header>}

      {!hideNavigation && <nav aria-label="下载中心导航" className="flex gap-1 border-b border-slate-200">
        {([['create', '新建下载'], ['history', '下载记录']] as const).map(([key, title]) => <button key={key} type="button" aria-pressed={view === key} onClick={() => setView(key)} className={`border-b-2 px-4 pb-3 pt-2 text-sm font-medium ${view === key ? 'border-sky-700 text-sky-700' : 'border-transparent text-slate-500 hover:text-slate-800'}`}>
          {title}{key === 'history' && runningCount > 0 && <span className="ml-2 rounded-full bg-sky-50 px-2 py-0.5 text-xs text-sky-700">{runningCount} 进行中</span>}
        </button>)}
      </nav>}

      {invalidBaizeMix && <p role="alert" className="wb-notice">白泽仅支持独立下载，请清除其他资料选择。</p>}
      {invalidXiaoxiangMix && <p role="alert" className="wb-notice">小象灯塔资料仅支持独立下载，请清除其他资料选择。</p>}
      {view === 'create' && baizeOnly && <p className="wb-notice">白泽导出全部员工原始资料，不按城市、日期筛选；登录完成后自动继续。不会生成绑定或执行薪资核算。</p>}
      {view==='create'&&merchantOnly&&<p className="wb-notice">按所选城市切换对应风神商家，读取各商家全部可见站点。邀请记录不加筛选、逐页全量获取；出勤明细按所选日期分段后合并为一个Excel。</p>}
      {view === 'create' && xiaoxiangOnly && <p className="wb-notice">{archiveOnly ? '小象灯塔骑手档案导出全部站点骑手的当前快照，手机号与身份证号为明文，照片以链接形式提供，无需选择日期。' : datasets[0] === 'rider_daily' ? '小象灯塔日维度骑手分析取商配送数据看板，默认昨天单日，可选择昨天及更早、最长31天的区间；区间逐日查询后按附件格式合并为一份工作簿，同比取上周同一天。' : `${(datasetLabel(datasets[0]) || '').replace('（小象灯塔）', '')}取商配送数据看板明细，固定全部站点、超时与评价类型为全部，默认昨天单日，可选择昨天及更早、最长31天的区间；区间逐日查询后合并为一份工作簿，某日无数据将跳过并记录。`}需要先在系统通道完成小象灯塔认证。</p>}
      {requestError && <div role="alert" className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700"><AlertCircle size={17} className="shrink-0 mt-0.5" />{requestError}<button type="button" aria-label="关闭错误提示" className="ml-auto shrink-0" onClick={() => setRequestError('')}><XCircle size={16} /></button></div>}
      {pollError && <p role="status" className="text-xs text-amber-700">{pollError}。连接恢复后自动更新。</p>}
      {uncertainRetry && <div role="status" className="rounded-lg bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800"><p>上次失败项处理结果尚未确认，请先确认原请求。</p><button type="button" className={`${smallButton} mt-2`} disabled={retryPending} onClick={() => void retrySelected()}>{retryPending ? '正在确认…' : '重新确认原分项请求'}</button></div>}

      {runs.some(run => ['waiting_login', 'waiting_manual'].includes(run.phase || '')) && <div role="status" className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800"><span>有任务正在等待登录或人工验证。</span><button type="button" className={smallButton} onClick={() => selectRun(runs.find(run => ['waiting_login', 'waiting_manual'].includes(run.phase || ''))!)}>查看并处理</button></div>}
      {uncertainCreate && view === 'history' && <div role="status" className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800"><span>原下载请求仍待确认，请先完成确认。</span><button type="button" className={smallButton} onClick={() => setView('create')}>返回确认原请求</button></div>}

      {view === 'create' && <>
        <TaskFlowSteps status="create" />

        <section className={`${panel} wb-task-form wb-download-workbench`} aria-label="新建下载配置">
          <div className="wb-form-heading"><h2>{taskKind === 'generate' ? '业务报表' : `${DOWNLOAD_PLATFORMS.find(value=>value.id===platform)?.label||'资料'}下载`}</h2><p className="wb-muted">{taskKind === 'generate' ? '选择目标表，系统关联来源资料。' : '选择所需资料，再确认处理范围。'}</p></div>
          {optionsError && !options ? <div role="alert" className="flex flex-wrap items-center gap-3 p-5 text-sm text-rose-700"><AlertCircle size={17} />{optionsError}<button className={smallButton} onClick={() => optionsError.includes('请刷新工作台') || optionsError.includes('账号页面已更新') ? location.reload() : setOptionVersion(version => version + 1)}>重新加载</button></div>
            : !options ? <p role="status" className="flex items-center gap-2 p-6 text-sm text-slate-500"><Loader2 size={16} />正在加载下载选项…</p>
            : <>
              {optionsError && <p role="alert" className="wb-full-span flex items-center gap-2 border-b border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-800 sm:px-6"><AlertCircle size={14} />城市清单刷新失败，仍显示上次结果：{optionsError}</p>}
              <div className="wb-download-main space-y-6 p-4 sm:p-6">
                {taskKind === 'generate' && <section className="wb-generation-form" aria-label="业务表生成配置">
                  <div className="wb-row wb-space">
                    <span className="wb-section-label">选择目标业务报表</span>
                    <span className="wb-muted">单次生成一张标准业务报表，底层来源自动关联校验</span>
                  </div>
                  <label className="sr-only"><span>生成内容</span><select className="wb-input" aria-label="生成内容" value={datasets[0] || 'payment_binding'} disabled={formLocked} onChange={event => { setDatasets([event.target.value]); setDuplicateApproval(''); }}>
                    {options.datasets.filter(dataset => isGenerator(dataset.id)).map(dataset => <option key={dataset.id} value={dataset.id}>{dataset.label.replace('（生成表）', '')}</option>)}
                  </select></label>
                  <div className="wb-report-card-grid" role="radiogroup" aria-label="业务报表类型卡片">
                    {GENERATION_REPORT_CARDS.filter(card => options.datasets.some(d => d.id === card.id)).map(card => {
                      const active = (datasets[0] || 'payment_binding') === card.id;
                      const genMeta = options.generators?.find(item => item.id === card.id);
                      return (
                        <button
                          key={card.id}
                          type="button"
                          role="radio"
                          aria-checked={active}
                          disabled={formLocked}
                          onClick={() => { setDatasets([card.id]); setDuplicateApproval(''); }}
                          className={`wb-report-card ${active ? 'is-selected' : ''}`}
                        >
                          <div className="wb-report-card-top">
                            <div className="wb-row gap-1.5">
                              {card.systems.map(sys => (
                                <span key={sys} className={`wb-sys-badge is-${sys === '蓝橙' ? 'lanorange' : 'fengshen'}`}>{sys}</span>
                              ))}
                            </div>
                            <span className="wb-report-granularity">{card.granularity}</span>
                          </div>
                          <strong className="wb-report-card-title">{card.title}</strong>
                          <p className="wb-report-card-desc">{genMeta?.description || card.summary}</p>
                        </button>
                      );
                    })}
                  </div>
                  {datasets[0] === 'abnormal_riders' && <p className="wb-notice">处理范围：全部城市、全量状态。不按城市和日期筛选，无需风神认证。</p>}
                  <details className="wb-generation-sources" open><summary>所需资料 · 系统自动关联（{options.generators?.find(item => item.id === datasets[0])?.sources.length || 0} 项）</summary><ul>{options.generators?.find(item => item.id === datasets[0])?.sources.map(source => <li key={source}><span>{source}</span><span className="wb-muted">执行时检查</span></li>)}</ul><p className="wb-muted">关键资料不完整时生成会停止，保留原任务供检查和恢复。</p></details>
                </section>}

                {taskKind === 'download' && <>
                <details className="wb-advanced"><summary>常用预设</summary><div className="wb-scenario-bar" role="region" aria-label="常用下载预设与核算场景包">
                  <div className="wb-row wb-space">
                    <div className="wb-row">
                      <span className="wb-scenario-title">下载预设</span>
                      {BUILTIN_DOWNLOAD_SCENARIOS.filter(scenario=>scenario.datasets.every(moduleDataset)).map(scenario => {
                        const isSelected = scenario.datasets.length > 0 && scenario.datasets.every(id => datasets.includes(id));
                        return (
                          <button
                            key={scenario.id}
                            type="button"
                            disabled={formLocked}
                            title={scenario.description}
                            aria-pressed={isSelected}
                            onClick={() => applyBuiltinScenario(scenario)}
                            className={`wb-scenario-chip ${isSelected ? 'is-active' : ''}`}
                          >
                            <span className={`wb-sys-badge is-${scenario.systemTag === '蓝橙' ? 'lanorange' : 'fengshen'}`}>{scenario.systemTag}</span>
                            <span>{scenario.name}</span>
                          </button>
                        );
                      })}
                      {presets.filter(preset=>preset.datasets.every(moduleDataset)).map(preset => (
                        <span key={preset.name} className="wb-custom-preset-chip">
                          <button type="button" className="text-sky-700 font-medium" onClick={() => applyPreset(preset)}>{preset.name}</button>
                          <button type="button" aria-label={`删除预设 ${preset.name}`} className="text-slate-400 hover:text-rose-600" onClick={() => removePreset(preset.name)}>×</button>
                        </span>
                      ))}
                    </div>
                    {presetInputOpen ? (
                      <div className="wb-row gap-1.5">
                        <input
                          className="wb-input text-xs py-1 px-2.5 w-40"
                          aria-label="新预设名称"
                          placeholder="输入预设名，如月末对账"
                          value={presetDraft}
                          onChange={event => setPresetDraft(event.target.value)}
                          onKeyDown={event => {
                            if (event.key === 'Enter') savePreset();
                            if (event.key === 'Escape') { setPresetInputOpen(false); setPresetDraft(''); }
                          }}
                        />
                        <button type="button" className="wb-primary text-xs py-1 px-3 min-h-[30px]" disabled={!presetDraft.trim()} onClick={() => savePreset()}>确认保存</button>
                        <button type="button" className="wb-button text-xs py-1 px-2.5 min-h-[30px]" onClick={() => { setPresetInputOpen(false); setPresetDraft(''); }}>取消</button>
                      </div>
                    ) : (
                      <button type="button" className={smallButton} disabled={formLocked || (!cities.length && !datasets.length)} onClick={() => setPresetInputOpen(true)}>保存当前选择为预设</button>
                    )}
                  </div>
                </div>
                </details>
                {!platform&&<div className="wb-system-overview-bar" role="group" aria-label="四大系统数据源切换">
                  <div className="wb-row">
                    <button
                      type="button"
                      aria-pressed={systemFilter === 'all'}
                      onClick={() => setSystemFilter('all')}
                      className={`wb-system-filter-btn ${systemFilter === 'all' ? 'is-active' : ''}`}
                    >
                      全部系统
                    </button>
                    {SYSTEM_META.map(sys => {
                      const isSelectableGroup = sys.key === 'fengshen' || sys.key === 'lanorange' || sys.key === 'baize' || sys.key === 'xiaoxiang';
                      const count = isSelectableGroup
                        ? datasets.filter(id => datasetGroup(id) === sys.key).length
                        : 0;
                      if (isSelectableGroup) {
                        return (
                          <button
                            key={sys.key}
                            type="button"
                            aria-pressed={systemFilter === sys.key}
                            title={`${sys.label}（${sys.businessLine}）：${sys.description}`}
                            onClick={() => setSystemFilter(prev => prev === sys.key ? 'all' : sys.key as 'fengshen' | 'lanorange' | 'baize' | 'xiaoxiang')}
                            className={`wb-system-filter-btn ${systemFilter === sys.key ? 'is-active' : ''}`}
                          >
                            <span>{sys.label}</span>
                            {count > 0 && <small className="wb-system-count">{count}</small>}
                          </button>
                        );
                      }
                      return (
                        <span
                          key={sys.key}
                          title={`${sys.label}（${sys.businessLine}）：${sys.description}`}
                          className={`wb-system-filter-tag ${sys.planned ? 'is-planned' : ''}`}
                        >
                          <span>{sys.label}</span>
                          <small>手动上传</small>
                        </span>
                      );
                    })}
                  </div>
                </div>}
                <fieldset aria-labelledby="download-datasets-label" className="wb-scope-section">
                  <div className="mb-3 flex items-center justify-between gap-3">
                    <span id="download-datasets-label" className="text-sm font-semibold text-slate-900">选择资料 <span className="ml-2 text-xs font-normal text-slate-500">已选 {datasets.length}</span></span>
                  </div>
                  {(['fengshen', 'lanorange', 'baize', 'xiaoxiang'] as const).filter(group => platform?group===platform:systemFilter === 'all' || systemFilter === group).map(group => <details key={group} className="wb-source-group" open><summary><span className={`wb-sys-badge mr-2 is-${group}`}>{group === 'baize' ? '白泽' : group === 'xiaoxiang' ? '小象灯塔' : group === 'lanorange' ? '蓝橙' : '风神'}</span>{group === 'baize' ? '白泽员工资料' : group === 'xiaoxiang' ? '小象灯塔资料' : group === 'lanorange' ? '蓝橙资料' : '风神资料'}<span className="wb-muted">已选 {datasets.filter(id => datasetGroup(id) === group).length}</span></summary><div className="wb-source-actions"><button type="button" disabled={formLocked} className="text-xs text-sky-700 hover:text-sky-800 font-medium" onClick={() => { const ids = visibleDatasets.filter(value => !isGenerator(value.id) && !isMerchant(value.id) && datasetGroup(value.id) === group).map(value => value.id); setDatasets(ids.every(id => datasets.includes(id)) ? datasets.filter(id => !ids.includes(id)) : group === 'baize' || group === 'xiaoxiang' ? ids : [...new Set([...datasets.filter(id => !isBaize(id) && !isXiaoxiang(id) && !isMerchant(id)), ...ids])]); }}>{group==='fengshen'?'全选城市资料 / 清空':'全选 / 清空本组'}</button></div>{group === 'lanorange' && <p className="wb-muted mb-2">原雷神 · 全量资料，每类交付一个文件。</p>}{group === 'xiaoxiang' && <p className="wb-muted mb-2">小象灯塔 · 独立日期区间，需先完成来源认证。</p>}<div className="grid grid-cols-2 gap-2 lg:grid-cols-3">{visibleDatasets.filter(value => !isGenerator(value.id) && datasetGroup(value.id) === group).map(dataset => <label key={dataset.id} className={`${choiceStyle(datasets.includes(dataset.id))} flex-wrap ${dataset.id === 'rider_monthly' ? 'col-span-2 sm:col-span-1' : ''}`}>
                    <input type="checkbox" checked={datasets.includes(dataset.id)} disabled={formLocked} onChange={() => {setDatasets(values=>toggleDownloadDataset(values,dataset.id));if(dataset.id==='attendance_detail'){if(end>attendanceLast)setEnd(attendanceLast);if(start>attendanceLast)setStart(attendanceLast);}}} className="accent-sky-700 shrink-0" />
                    <span className="flex-1 leading-snug">{dataset.label}</span>
                    <span className="basis-full pl-5 text-[11px] text-slate-500">{isBaize(dataset.id) ? '独立全量' : isRiderArchive(dataset.id) ? '实时快照' : isXiaoxiang(dataset.id) ? '独立区间' : isMerchant(dataset.id)?isMerchantSnapshot(dataset.id)?'所选城市全量':'全部团队 · 分段合并':isLanorange(dataset.id) ? (dataset.id === 'abnormal_riders' ? '生成表' : dataset.id === 'lanorange_part_price' && !blueOnly ? '按月' : '全量') : MONTHLY_DATASETS.has(dataset.id) ? '整月' : SNAPSHOT_DATASETS.has(dataset.id) ? '快照' : ['payment_binding', 'abnormal_followup'].includes(dataset.id) ? '按月拆分' : '按日期'}</span>
                  </label>)}</div></details>)}
                </fieldset>

                </>}


                {!noCity && (taskKind === 'generate' || datasets.length > 0) && <fieldset aria-labelledby="download-cities-label" className="wb-scope-section">
                  <div className="wb-row wb-space"><span id="download-cities-label" className="wb-section-label">处理城市 <span className="wb-muted">已选 {cities.length}</span></span><button className="wb-button" disabled={formLocked} onClick={() => { setCitySearch(''); setCityPickerOpen(true); }}>选择城市</button></div>
                  <div className="wb-city-tags">{cities.map(city => <button key={city} className="wb-city-tag" disabled={formLocked} aria-label={`移除城市 ${city}`} onClick={() => toggle(city, cities, setCities)}>{city}<span aria-hidden="true">×</span></button>)}{!cities.length && <span className="wb-muted">请选择本次处理的城市</span>}</div>
                  {cityPickerOpen && <WorkbenchDrawer title="选择城市" onClose={() => setCityPickerOpen(false)}>
                    <input className="wb-input" aria-label="搜索城市" placeholder="搜索城市" value={citySearch} onChange={event => setCitySearch(event.target.value)} />
                    <div className="wb-row wb-space"><span className="wb-muted">{citySourceLabel}</span><button type="button" className="wb-link" disabled={formLocked || optionsLoading} onClick={() => setOptionVersion(version => version + 1)}>{optionsLoading ? '同步中' : '刷新城市清单'}</button></div>
                    <div className="wb-row wb-space"><span>已选 {cities.length} 个城市</span><button className="wb-link" disabled={formLocked || !selectableCities.length} onClick={() => setCities(cities.length === selectableCities.length ? [] : selectableCities.map(city => city.name))}>{cities.length === selectableCities.length && cities.length ? '清空城市' : '全选城市'}</button></div>
                  <div className="wb-city-grid">{options.cities.filter(city => city.name.includes(citySearch.trim())).map(city => {
                    return (
                      <label key={city.id} title={city.disabled ? city.note : undefined} className={`${choiceStyle(!city.disabled && cities.includes(city.name))} ${city.disabled ? 'cursor-not-allowed opacity-50 hover:border-slate-200' : ''}`}>
                        <input type="checkbox" checked={!city.disabled && cities.includes(city.name)} disabled={formLocked || city.disabled} onChange={() => toggle(city.name, cities, setCities)} className="accent-sky-700 shrink-0" />
                        <span className="break-words flex-1">{city.name}</span>
                        {city.disabled && (
                          <span className="ml-auto shrink-0 rounded bg-slate-200 px-1.5 py-0.5 text-[10px] text-slate-500">{city.note || '已下架'}</span>
                        )}
                      </label>
                    );
                  })}</div>
                    {!options.cities.some(city => city.name.includes(citySearch.trim())) && <p className="wb-empty">没有匹配的城市</p>}
                    {!selectableCities.length && <p className="wb-notice">暂无可下载城市，请检查风神权限或主机网络。</p>}
                    <div className="wb-picker-footer"><button className="wb-primary" onClick={() => setCityPickerOpen(false)}>完成选择 · {cities.length} 个城市</button></div>
                  </WorkbenchDrawer>}
                </fieldset>}

                {!noDate && (taskKind === 'generate' || datasets.length > 0) && <fieldset aria-labelledby="download-dates-label" className="wb-scope-section">
                  <legend className="sr-only">下载日期</legend>
                  <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                    <p id="download-dates-label" className="text-sm font-semibold text-slate-900">处理日期 <span className="ml-2 text-xs font-normal text-slate-500">北京时间</span></p>
                    {!xiaoxiangOnly && <div className="wb-period-quick-bar" role="group" aria-label="核算账期快捷选择">
                      {([
                        ['last_full_month', '上月整月'],
                        ['current_first_half', '本月1-15日'],
                        ['last_second_half', '上月16-月末'],
                        ['current_month_to_date', '本月至今'],
                      ] as const).map(([presetKey, label]) => {
                        const range = computeBillingPeriodRange(presetKey, shanghaiToday());
                        const effectiveStart=merchantOnly&&range.start<attendanceFirst?attendanceFirst:range.start;
                        const effectiveEnd=merchantOnly&&range.end>attendanceLast?attendanceLast:range.end;
                        const isCurrent = start === effectiveStart && end === effectiveEnd;
                        return (
                          <button
                            key={presetKey}
                            type="button"
                            disabled={formLocked||effectiveStart>effectiveEnd}
                            aria-pressed={isCurrent}
                            onClick={() => applyBillingPeriod(presetKey)}
                            className={`wb-period-chip ${isCurrent ? 'is-active' : ''}`}
                          >
                            {merchantOnly&&presetKey==='current_month_to_date'?'本月至昨日':label}
                          </button>
                        );
                      })}
                    </div>}
                  </div>
                  <div className="grid max-w-xl grid-cols-2 gap-3">
                    <label className="flex min-w-0 flex-col gap-1.5 text-xs text-slate-500"><span>开始日期</span><input type="date" aria-label="下载开始日期" min={merchantOnly?attendanceFirst:xiaoxiangOnly?xiaoxiangFirst:undefined} max={merchantOnly?attendanceLast:xiaoxiangOnly?dailyDate:undefined} value={start} disabled={formLocked} onChange={event => setStart(event.target.value)} className={fieldStyle} /></label>
                    <label className="flex min-w-0 flex-col gap-1.5 text-xs text-slate-500"><span>结束日期</span><input type="date" aria-label="下载结束日期" min={merchantOnly?attendanceFirst:xiaoxiangOnly?xiaoxiangFirst:undefined} max={merchantOnly?attendanceLast:xiaoxiangOnly?dailyDate:undefined} value={end} disabled={formLocked} onChange={event => setEnd(event.target.value)} className={fieldStyle} /></label>
                  </div>

                  {!validDates && <p role="alert" className="mt-2 text-xs text-rose-700">开始日期不能晚于结束日期，请选择有效日期。</p>}
                  {xiaoxiangOnly && validDates && !xiaoxiangDateValid && <p role="alert" className="mt-2 text-xs text-rose-700">小象灯塔资料只能选择昨天及更早的日期，且区间最长31天。</p>}
                  {xiaoxiangOnly && validDates && xiaoxiangDateValid && <p className="mt-2 text-xs leading-relaxed text-sky-700">{start===end?'单日工作簿：按所选日期生成。':datasets[0]==='rider_daily'?`区间合并：逐日查询 ${xiaoxiangSpanDays} 天数据，按附件20列格式合并；某日无数据将跳过并记录。`:`区间合并：逐日查询 ${xiaoxiangSpanDays} 天数据；某日无数据将跳过并记录。`}</p>}
                  {monthPreview.length > 0 && <p className="mt-2 text-xs leading-relaxed text-sky-700">整月资料自动下载：{monthPreview.join('、')}。</p>}
                  {!merchantOnly&&<details className="wb-advanced"><summary>站点范围与高级选项 · {includeSeparation ? '仅取分离站点' : '排除取分离站点'}</summary><div className="space-y-3 mt-3">
                  {datasets.includes('lanorange_part_price') && <p className="mt-2 text-xs text-slate-500">价格档案交付副本按日期覆盖的月份筛选；仅勾选蓝橙资料时没有日期选择，保留全部日期。原始平台全量文件始终保留在主机。</p>}
                  {datasets.includes('rider_info') && <p className="mt-2 text-xs text-slate-500">骑手信息为当前快照，不按日期筛选。</p>}
                  {datasets.includes('goods_rent') && <p className="mt-2 text-xs text-slate-500">物资租用登记为全历史快照，不按日期筛选；站点按「是否含取分离」勾选过滤。</p>}
                  <div className="mt-3 space-y-1 text-xs text-slate-500">
                    <label className="flex items-center gap-2"><input type="checkbox" aria-label="是否含取分离站点" checked={includeSeparation} disabled={formLocked} onChange={event => setIncludeSeparation(event.target.checked)} />是否含取分离站点</label>
                    <p>按站点名称是否含「取分离」过滤全部风神资料：勾选后仅保留取分离站点，不勾选默认排除取分离站点。原始全量文件保留在原始资料目录；过滤后站点为空时生成空表。</p>
                  </div>
                  {datasets.includes('payment_binding') && <p className="mt-2 text-xs text-slate-500">按月生成，仅保留周期内有单骑手。代领须为该月启用记录，审核通过优先，其次审批中。多城市另生成每月汇总文件，失败城市在汇总中单列；每次生成刷新全部来源。</p>}
                  {datasets.includes('abnormal_followup') && <p className="mt-2 text-xs text-slate-500">异常骑手跟进以骑手支付绑定为基准，自动关联物资租用登记、风神骑手月度 UB 账单、价格档案、骑手档案；按城市按月生成。分析表H/I/J统计所有活跃天大于0的骑手，不再按异常标记筛选；其他业务判断保持原口径。</p>}
              {datasets.includes('abnormal_riders') && <p className="mt-2 text-xs text-slate-500">异常骑手整理自动关联 5 类蓝橙资料（批量离职、骑手离职、离职报备、骑手请假、骑手档案），任务完成后按全部城市生成一份整理工作簿（异常汇总、蓝橙骑手档案、汇总），无需风神登录；若同任务勾选了骑手数据明细/骑手信息，将补充总单量与活跃异常判定。</p>}
                  {datasets.some(dataset => ['fraud', 'problem'].includes(dataset)) && <div className="mt-3 space-y-1 text-xs text-slate-500"><label className="flex items-center gap-2"><input type="checkbox" checked={refreshHistory} disabled={formLocked} onChange={event => setRefreshHistory(event.target.checked)} />重新获取历史运单</label><p>默认复用 24 小时内已校验的历史资料；当天资料始终刷新。平台资料有补录或修改时，可勾选重新获取。</p></div>}
                  </div></details>}
                  {merchantOnly && <p className="wb-notice">团队固定为各城市商家全部可访问站点；按最多7天及官方时段切换日期分段，完成后合并领取。仅支持最近90天内、早于今天的日期。</p>}
                  {orderWindowWarning && <p role="alert" className="mt-3 rounded-lg bg-amber-50 border border-amber-200 p-3 text-xs text-amber-800">欺诈单和问题单仅支持最近 {orderWindowDays} 天（{earliestOrder} 至 {shanghaiToday()}），请调整日期或取消这两类资料。</p>}
                </fieldset>}
                {uncertainCreate && <p className="wb-notice">原请求资料：{createAttempt.current?.payload.datasets.map(datasetLabel).join('、')}。本次继续确认原请求，分类不改变其内容。</p>}
                {uncertainCreate && <p role="status" className="rounded-lg bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800">上次提交结果尚未确认，已锁定原选择。请点击“重新确认原请求”，继续确认同一任务。</p>}
                {!uncertainCreate && matchingRun && <div className="rounded-lg bg-sky-50 border border-sky-200 p-3 text-xs text-sky-800 space-y-2"><p>{completedMatch ? '相同选择已有文件，可直接查看和下载。' : '相同选择已有任务正在执行，可直接查看进度。'}</p>{completedMatch && <label className="flex items-center gap-2"><input type="checkbox" checked={duplicateApproval === currentSelectionKey} disabled={creating} onChange={event => setDuplicateApproval(event.target.checked ? currentSelectionKey : '')} />重新采集，创建新版本</label>}</div>}
              </div>
              <aside className="wb-task-preview" aria-label="本次任务实时清单">
                <div className="wb-preview-header">
                  <div>
                    <h4>本次任务预览</h4>
                    <p className="wb-muted">实时汇总当前配置范围与产出预期</p>
                  </div>
                  <span className="wb-kind-badge">{taskKind === 'generate' ? '业务表生成' : '资料下载'}</span>
                </div>
                <div className="wb-preview-metrics">
                  <div>
                    <strong>{datasets.length}</strong>
                    <span>{taskKind === 'generate' ? '目标报表' : '已选资料'}</span>
                  </div>
                  <div>
                    <strong>{blueOnly || xiaoxiangOnly ? '全部' : cities.length}</strong>
                    <span>处理城市</span>
                  </div>
                  <div>
                    <strong>{taskKind === 'generate' ? (datasets[0] === 'abnormal_riders' ? 1 : cities.length * Math.max(1, monthPreview.length)) : subitemCount}</strong>
                    <span>预计子项</span>
                  </div>
                </div>
                <div className="wb-preview-block">
                  <h5>{taskKind === 'generate' ? '生成目标与关联来源' : '已选资料清单'}</h5>
                  {datasets.length > 0 ? (
                    <ul className="wb-preview-list">
                      {datasets.map(id => (
                        <li key={id}>
                          <span>{datasetLabel(id).replace('（生成表）', '')}</span>
                          <small>{isBaize(id) ? '白泽全量' : isRiderArchive(id) ? '全部站点实时快照' : isXiaoxiang(id) ? (start===end?'灯塔单日':'灯塔区间合并') : isMerchant(id)?isMerchantSnapshot(id)?'各城市商家全分页':'全部团队 · 分段合并':isLanorange(id) ? (id === 'abnormal_riders' ? '全量生成表' : id === 'lanorange_part_price' && !blueOnly ? '按月筛选' : '蓝橙全量') : MONTHLY_DATASETS.has(id) ? '整月数据' : SNAPSHOT_DATASETS.has(id) ? '实时快照' : ['payment_binding', 'abnormal_followup'].includes(id) ? '按月生成' : '按日采集'}</small>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="wb-muted">请在左侧勾选至少一项需要采集的资料</p>
                  )}
                </div>
                <div className="wb-preview-block">
                  <h5>处理范围与周期</h5>
                  <dl className="wb-preview-dl">
                    <div>
                      <dt>城市范围</dt>
                      <dd>{archiveOnly ? '账号全部站点（当前快照）' : xiaoxiangDated ? '账号可访问全部城市（按日期区间）' : blueOnly ? '全部城市（全量交付）' : cities.length ? `${cities.slice(0, 6).join('、')}${cities.length > 6 ? ` 等 ${cities.length} 城` : ''}` : '待选择城市'}</dd>
                    </div>
                    <div>
                      <dt>业务日期</dt>
                      <dd className="font-mono">{archiveOnly?'当前快照，不按日期筛选':merchantSnapshotOnly?'不按日期筛选':xiaoxiangDated ? (start===end?`${start}（单日）`:`${start} ~ ${end}（共 ${xiaoxiangSpanDays} 天）`) : blueOnly ? '不按日期筛选' : `${start} ~ ${end}`}</dd>
                    </div>
                    {!noDate && monthPreview.length > 0 && (
                      <div>
                        <dt>折算月份</dt>
                        <dd>{monthPreview.join('、')}</dd>
                      </div>
                    )}
                    {!noCity && (
                      <div>
                        <dt>站点规则</dt>
                        <dd>{merchantOnly?'各城市商家全部可访问站点':includeSeparation ? '仅保留「取分离」站点' : '默认排除「取分离」站点'}</dd>
                      </div>
                    )}
                  </dl>
                </div>
                <div className="wb-preview-block wb-preview-status">
                  <h5>认证与前置检查</h5>
                  <p className="wb-muted">
                    {baizeOnly ? '● 白泽独立全量导出；提交后检查白泽登录，无需风神或蓝橙登录。' : xiaoxiangOnly ? '● 小象灯塔独立导出；需先在系统通道完成小象灯塔认证，无需风神或蓝橙登录。' : datasets.some(id => !isLanorange(id))
                      ? fengshenAuthStatus?.state === 'ready'
                        ? '● 风神平台会话已就绪，可直接启动任务。'
                        : '● 含风神平台资料，提交后将自动检测或提示验证登录。'
                      : datasets.length > 0
                        ? '● 纯蓝橙全量资料，无需风神登录。'
                        : '● 选择资料后自动检测所需数据源连接状态。'}
                  </p>
                </div>
              </aside>
              <footer className="wb-action-bar">
                <p className={`text-sm ${submitReady ? 'text-slate-600' : 'text-amber-700'}`}>{submitHint}{submitReady && !noDate && <span className="wb-submit-range">{xiaoxiangOnly ? `全部城市 · ${start} 至 ${end}` : `${cities.slice(0, 2).join('、')}${cities.length > 2 ? '等' : ''} · ${start} 至 ${end}`}</span>}</p>
                <button type="button" onClick={() => void startDownload()} disabled={creating || (!uncertainCreate && !canSubmit)} className={`${primaryButton} w-full sm:w-auto`}>
                  {creating ? <Loader2 size={17} /> : <CloudDownload size={17} />}{creating ? '正在确认任务…' : uncertainCreate ? '重新确认原请求' : matchingRun && !TERMINAL_STATUSES.has(matchingRun.status) ? '查看任务进度' : completedMatch && duplicateApproval !== currentSelectionKey ? '查看已有文件' : taskKind === 'generate' ? '准备资料并生成' : '开始下载'}
                </button>
              </footer>
            </>}
        </section>
                <details className="px-1 text-xs leading-relaxed text-slate-500">
          <summary className="cursor-pointer w-fit">下载与保存说明</summary>
          <div className="mt-3 space-y-2 rounded-xl bg-slate-50 border border-slate-200 p-4">
            <p>任务创建后会在主机继续执行，离开页面不影响下载。需要登录或额外验证时会显示提示。</p>
            <p>资料先保存到主机，点击“下载全部文件”或“保存文件”可保存到当前设备。</p>
            <p>主机保存位置：<span className="break-all font-mono">{options?.archive_root || 'outputs/fengshen_downloads'}</span></p>
            <p>同一任务的所有城市文件放在同一文件夹，文件名包含城市、资料类型和业务日期。</p>
            <p>整月资料覆盖所选日期涉及的全部月份；骑手风神绑定下载收薪账户原始资料；骑手信息为当前快照。</p>
          </div>
        </details>
      </>}

      {scopeReview && <WorkbenchDrawer title="确认新任务范围" onClose={() => setScopeReview(null)}>
        <TaskFlowSteps status="review" />
        <dl className="wb-scope-review"><dt>本次业务</dt><dd>{scopeReview.task_kind === 'generate' ? '业务报表生成' : '资料下载'}</dd>
        <dt>资料或报表</dt><dd>{scopeReview.datasets.map(datasetLabel).join('、')}</dd>
        <dt>城市范围</dt><dd>{scopeReview.datasets.length===1&&isRiderArchive(scopeReview.datasets[0]) ? '账号全部站点 · 当前快照' : scopeReview.datasets.every(isXiaoxiang) ? '账号可访问全部城市 · 日期区间导出' : scopeReview.datasets.every(isGlobalDataset) ? '全部城市 · 按现有全量规则' : scopeReview.cities.join('、')}</dd>
        <dt>日期范围</dt><dd>{scopeReview.datasets.length===1&&isRiderArchive(scopeReview.datasets[0])?'当前快照，不按日期筛选':scopeReview.datasets.every(isMerchantSnapshot)?'邀请记录全量，不按日期筛选':scopeReview.datasets.every(isGlobalDataset) ? '全量交付，不按所选日期筛选' : `${scopeReview.start} 至 ${scopeReview.end}`}</dd></dl>
        <p className="wb-notice">这是新建任务。继续已有任务请返回任务中心；页面关闭或返回修改不会提交导出。</p>
        {scopeReview.task_kind === 'generate' && <p className="wb-muted">系统按既有规则关联来源资料；关键资料不完整时保留任务并提示处理，不代表所有来源均可自动复用。</p>}
        <div className="wb-row"><button type="button" className="wb-button" onClick={() => setScopeReview(null)}>返回修改范围</button><button type="button" className="wb-primary" disabled={creating} onClick={() => {
          const key=selectionKey(scopeReview); setScopeReview(null);
          if (key !== currentSelectionKey) { setRequestError('范围已发生变化，请重新确认后创建任务'); return; }
          void startDownload(key);
        }}>确认并创建任务</button></div>
      </WorkbenchDrawer>}

      {view === 'history' && <DownloadRecords key={recordModule||'all'} recordModule={recordModule} apiFetch={apiFetch} workspaceId={workspaceId} selectedRunId={selectedId}
        datasetLabel={id => id === 'payroll' ? '兼职薪资核算' : datasetLabel(id)} refreshVersion={navigation?.version} unified onOpenPayroll={onOpenPayroll}
        onNavigateGenerate={onNavigateGenerate}
        onNavigatePayroll={onNavigatePayroll}
        onOpenAttempt={id => {
          setRequestError('');
          attemptOpenController.current?.abort();
          const controller = new AbortController(); attemptOpenController.current = controller;
          void getJson(`${API_ROOT}/runs/${encodeURIComponent(id)}`, { signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]) })
            .then(data => { if (!controller.signal.aborted) selectRun(data.run); }).catch(error => { if (!controller.signal.aborted) setRequestError(error.message); });
        }}
        execution={<>
{selectedRun && <div className={`${panel} wb-task-detail min-w-0 space-y-4 p-4 sm:p-5`}>
              <TaskFlowSteps status={selectedRun.status} />
              <section className="wb-task-recovery" aria-label="任务恢复与资料保留" role="status">
                <strong>{waitingLogin ? '等待本人完成平台验证' : activeRun ? '正在处理原任务' : '已保留本任务资料'}</strong>
                <p>{selectedRun.cities.join('、')} · {selectedRun.start} 至 {selectedRun.end} · 编号 {selectedRun.archive_code || selectedRun.id.slice(0,6).toUpperCase()}</p>
                {(() => { const info = recoverySummary(selectedRun.items || []); return <p>已完成 {info.retained} 项 · 可继续 {info.continuing} 项 · 未提交可重试 {info.unsubmitted} 项 · 需核对 {info.blocked} 项</p>; })()}
                <small>关闭页面不取消任务。优先复用已保留资料；结果未知时先核对原回执，不自动重提导出。</small>
              </section>
              {/* 置顶最终成品交付清单 */}
              {(() => {
                const primaryFiles = (selectedRun.files || []).filter(f => f.name.endsWith('.xlsx') || f.name.endsWith('.xls'));
                const otherFiles = (selectedRun.files || []).filter(f => !f.name.endsWith('.xlsx') && !f.name.endsWith('.xls'));
                return primaryFiles.length > 0 ? (
                  <div className="p-3.5 rounded-xl border border-emerald-300 bg-emerald-50/80 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                        <FileSpreadsheet size={15} className="text-emerald-700" />
                        最终成品交付工作簿 ({primaryFiles.length})
                      </span>
                      <span className="rounded bg-emerald-200 text-emerald-900 text-[10px] font-bold px-2 py-0.5">置顶成品</span>
                    </div>
                    <div className="space-y-1.5">
                      {primaryFiles.map(file => (
                        <div key={file.id} className="flex items-center justify-between gap-2 p-2 rounded-lg bg-white border border-emerald-200 text-xs shadow-xs">
                          <div className="min-w-0 flex-1">
                            <span className="font-semibold text-slate-800 truncate block">{file.name}</span>
                            <small className="text-slate-500">{file.city} · {(file.bytes / 1024).toFixed(1)} KB</small>
                          </div>
                          <button type="button" disabled={!!fileBusy} onClick={() => void downloadFile(file.id, file.name)}
                            className="wb-primary text-xs py-1 px-3 inline-flex items-center gap-1 shrink-0">
                            <Download size={13} />
                            {fileBusy === file.id ? '下载中…' : '一键下载'}
                          </button>
                        </div>
                      ))}
                    </div>

                    {/* 跨页面流水线联动操作 */}
                    {!selectedRun.datasets.every(isBaize) && selectedRun.cities?.length > 0 && (onNavigateGenerate || onNavigatePayroll) && (
                      <div className="pt-2 border-t border-emerald-200 flex flex-wrap gap-2">
                        {onNavigateGenerate && (
                          <button
                            type="button"
                            className="wb-button text-xs py-1 px-2.5 bg-white border-emerald-300 text-emerald-800 hover:bg-emerald-100 font-medium inline-flex items-center gap-1 shadow-xs"
                            onClick={() => onNavigateGenerate(selectedRun.cities, selectedRun.start, selectedRun.end)}
                          >
                            <FileSpreadsheet size={13} />
                            以此数据生成报表
                          </button>
                        )}
                        {onNavigatePayroll && (
                          <button
                            type="button"
                            className="wb-button text-xs py-1 px-2.5 bg-white border-emerald-300 text-emerald-800 hover:bg-emerald-100 font-medium inline-flex items-center gap-1 shadow-xs"
                            onClick={() => onNavigatePayroll(selectedRun.cities[0])}
                          >
                            <Calculator size={13} />
                            以此数据发起兼职结算
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                ) : null;
              })()}

              <div className="flex flex-wrap items-start justify-between gap-3">
                <div><h3 className="flex flex-wrap items-center gap-2 text-base font-semibold text-slate-900">{selectedRun.datasets.every(isBaize) ? '白泽全量员工资料' : selectedRun.datasets.every(isLanorange) ? (selectedRun.lanorange_by_city ? `蓝橙 ${selectedRun.cities.join('、')}` : '蓝橙全量') : selectedRun.cities.length > 2 ? `${selectedRun.cities.length} 个城市` : selectedRun.cities.join('、')}的下载任务 <span className={`rounded-md px-2 py-1 text-xs font-normal ${statusInfo(selectedRun.status).color}`}>{runStatusLabel}</span></h3><p className="mt-2 text-xs text-slate-500">{selectedRun.datasets.every(isLanorange) ? (selectedRun.lanorange_by_city ? '所选城市、全部状态、不按日期筛选' : '全部城市、全部状态、不按日期筛选') : `${selectedRun.start} 至 ${selectedRun.end}`} · {selectedRun.datasets.length} 类资料</p></div>
                {!activeRun && <details><summary className="wb-link">需要重新采集？</summary><p className="text-xs">先处理下方可恢复项。新任务不会继续原导出；结果未知时请先核对原回执。</p><button type="button" className={smallButton} disabled={selectedRun.items?.some(item => item.submission_state === 'unknown')} onClick={() => prefillFromRun(selectedRun)}>重新采集并创建新任务</button></details>}
                {activeRun && <button type="button" className={smallButton} disabled={cancelling || ['cancelling', 'canceling'].includes(selectedRun.status)} onClick={() => void cancelDownload()}>{cancelling ? <Loader2 size={13} /> : <Square size={13} />}停止任务</button>}
              </div>
              <div role="status" className="space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500"><span>{activeRun ? phaseLabel(selectedRun.phase) : statusInfo(selectedRun.status).label}{selectedRun.queue_position ? ` · 排队第 ${selectedRun.queue_position} 位` : ''}{activeRun && selectedRun.phase_since ? ` · ${elapsed(selectedRun.phase_since)}` : ''}</span><span>{Math.round(progress)}%</span></div>
                {selectedRun.status === 'queued' && <p className="wb-muted">{selectedRun.queue_wait_reason === 'local_capacity' ? '正在等待本机处理名额；最多同时保留两个在途任务。' : '正在等待前一项平台采集结束；采集完成后的纯蓝橙整理可释放队列。'}</p>}
                <div role="progressbar" aria-label="下载进度" aria-valuenow={Math.round(progress)} aria-valuemin={0} aria-valuemax={100} className="h-1.5 overflow-hidden rounded-full bg-slate-200"><div style={{ width: `${progress}%` }} className="h-full bg-sky-700" /></div>
                {summaryHint && <p role="status" className={`text-xs ${summaryDetail?.stage === 'failed' ? 'text-rose-700' : 'text-sky-700'}`}>{summaryHint}</p>}
                {summary && typeof summary.total === 'number' && <p className="text-xs text-slate-500">完成 {summary.success || 0} / {summary.total} 项{summary.error ? ` · 失败 ${summary.error} 项` : ''}{summary.cancelled ? ` · 取消 ${summary.cancelled} 项` : ''}</p>}
                {typeof selectedRun.summary === 'string' && <p className="text-xs text-slate-500">{selectedRun.summary}</p>}
                {selectedRun.order_progress && <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs text-slate-700 space-y-1" aria-label="运单分批处理进度"><p>{({ collecting: '采集资料与后台处理并行中', processing: '本地校验处理中', merging: '合并并生成成品', completed: '分批处理完成' } as Record<string, string>)[selectedRun.order_progress.stage || ''] || '运单处理中'} · 批次 {selectedRun.order_progress.batch || 0}/{selectedRun.order_progress.batches || 0}</p><p>已获取 {selectedRun.order_progress.obtained || 0} 批 · 已校验 {selectedRun.order_progress.processed || 0} 批 · 已处理 {(selectedRun.order_progress.processed_rows || 0).toLocaleString()} 条运单</p><p>复用历史 {selectedRun.order_progress.cached_days || 0} 天 · 本次下载 {formatSize(selectedRun.order_progress.download_bytes || 0)} · 已用 {Math.round(selectedRun.order_progress.elapsed_seconds || 0)} 秒</p></div>}
              </div>
              {waitingLogin && <div className="rounded-lg bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800">{selectedRun.datasets.some(id => isLanorange(id) || isBaize(id) || isXiaoxiang(id)) ? <><p>此任务需要来源认证。</p><button className={`${smallButton} mt-2`} onClick={() => window.dispatchEvent(new CustomEvent('workbench:connections', { detail: selectedRun.datasets.some(isBaize) ? 'baize' : selectedRun.datasets.some(isXiaoxiang) ? 'xiaoxiang' : 'lanorange' }))}>完成验证</button></> : <><p>完成风神登录后，任务会继续。</p>{onOpenFengshenLogin ? <button type="button" onClick={() => onOpenFengshenLogin(user.id)} className={`${smallButton} mt-2`}><KeyRound size={14} />打开风神登录</button> : <p>请在运行系统的电脑上完成风神登录。</p>}</>}</div>}
              {selectedRun.phase === 'waiting_manual' && <p role="status" className="rounded-lg bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800">平台要求额外验证，当前任务已暂停。请打开风神验证窗口查看具体原因。</p>}
              {selectedRun.error && <p role="alert" className="rounded-lg bg-rose-50 border border-rose-200 p-3 text-xs text-rose-700 break-words">{selectedRun.error}</p>}

              {canRecoverDetail(selectedRun) && <div className="rounded-lg bg-sky-50 border border-sky-200 p-3 text-xs text-sky-800"><p>可继续查询已提交的明细任务。</p><button type="button" className={`${smallButton} mt-2`} disabled={!!resumingRunId} onClick={() => void resumeDetail()}>{resumingRunId ? <Loader2 size={14} /> : <RefreshCw size={14} />}恢复已有明细下载</button>{recoveryError?.runId === selectedRun.id && <p role="alert" className="mt-2 text-amber-700">{recoveryError.message}</p>}</div>}
              {!!selectedRun.items?.length && <details key={`items-${selectedRun.id}`} open={failedItems.length > 0} className="border-t border-slate-200 pt-3">
                <summary className="cursor-pointer text-sm text-slate-700">任务明细{failedItems.length > 0 ? ` · ${failedItems.length} 项需要处理` : ` · ${selectedRun.items.length} 项`}</summary>
                <div className="mt-3 space-y-3">
                  {!activeRun && selectedRecoverable.length > 0 && <div className="flex flex-wrap items-center justify-between gap-2"><label className="flex items-center gap-2 text-xs"><input type="checkbox" disabled={retryPending || uncertainRetry} checked={selectedRecoverable.every(item => retryKeys.includes(itemKey(item)))} onChange={event => setRetryKeys(event.target.checked ? selectedRecoverable.map(itemKey) : [])} />全选可恢复项</label><button type="button" className={smallButton} disabled={retryPending || uncertainRetry || !selectedRecoverable.some(item => retryKeys.includes(itemKey(item)))} onClick={() => void retrySelected()}>{retryPending ? <Loader2 size={14} /> : <RefreshCw size={14} />}处理选中的失败项</button></div>}
                  <div className="max-h-96 space-y-2 overflow-y-auto">{selectedRun.items.map((item, index) => <div key={`${itemKey(item)}-${index}`} className="rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs">
                    <div className="flex items-start justify-between gap-3"><label className="flex items-start gap-2">{!activeRun && recoverable(item) && <input aria-label={`选择处理${item.city}${datasetLabel(item.dataset)}${item.start}`} type="checkbox" disabled={retryPending || uncertainRetry} checked={retryKeys.includes(itemKey(item))} onChange={() => toggle(itemKey(item), retryKeys, setRetryKeys)} />}<span className="font-medium text-slate-800">{item.city} · {datasetLabel(item.dataset)}</span></label><span className={`shrink-0 rounded px-1.5 py-0.5 ${statusInfo(item.status).color}`}>{statusInfo(item.status).label}</span></div>
                    <p className="mt-1.5 text-slate-500">{isBaize(item.dataset) ? '白泽全量员工原表 · 不按城市或日期筛选' : isRiderArchive(item.dataset) ? '小象灯塔骑手档案 · 全部站点当前快照 · 手机号/身份证为明文 · 照片以链接提供' : isXiaoxiang(item.dataset) ? (item.start===item.end ? `小象灯塔商配送看板 · ${item.start} 单日 · 全部站点一份工作簿` : `小象灯塔商配送看板 · ${item.start} 至 ${item.end} 区间合并 · 全部站点一份工作簿${item.dataset === 'rider_daily' ? ' · 按附件20列格式' : ''}`) : item.dataset === 'abnormal_riders' ? '生成表 · 由本任务的 5 类蓝橙成品整理生成（全部城市一份）' : isLanorange(item.dataset) ? (item.city === '全部城市' ? selectedRun.lanorange_full_delivery ? '全量统一交付 · 全部状态、无日期筛选；缺失批次不计为完成' : '全量原始表 · 全部城市、全部状态、无业务筛选' : item.dataset === 'lanorange_batch_quit' ? '平台城市批次原表 · 汇总按骑手城市归属筛选' : '城市原始表 · 全部状态、不按日期筛选') : item.dataset === 'rider_info' ? '当前快照' : `${item.start} 至 ${item.end}`}{item.phase && !['completed', 'failed', 'cancelled', 'interrupted'].includes(item.phase) ? ` · ${phaseLabel(item.phase)}` : ''}</p>
                    {item.error && <p className="mt-2 break-words text-rose-700">{item.error}</p>}
                    {!activeRun && item.status !== 'success' && item.recovery && <div className="mt-2"><p className={item.recovery.mode === 'blocked' ? 'text-amber-800' : 'text-sky-800'}>{!recoverable(item) ? '需人工核对后处理' : item.recovery.mode === 'resume_existing' ? '复用已有资料，继续处理' : '尚未提交，可重新执行'}</p><details open className="mt-1 text-slate-500"><summary className="cursor-pointer">原因与处理说明</summary><p className="mt-2 leading-relaxed">{item.recovery.reason}</p>{item.failure_phase && <p className="mt-1">失败阶段：{phaseLabel(item.failure_phase)}</p>}</details>{recoverable(item) && <button type="button" className="wb-button wb-item-recovery" disabled={retryPending || uncertainRetry} onClick={() => void retrySelected(item)}>{item.recovery.mode === 'resume_existing' ? '继续此项已有资料' : '仅重试此未提交项'}</button>}</div>}
                  </div>)}</div>
                </div>
              </details>}
              {selectedRun.performance && <details className="wb-performance"><summary>底层运行诊断（耗时与内存）</summary>
                <div className="wb-row wb-muted"><span>总耗时（含认证、汇总） {Number(selectedRun.performance.total_seconds ?? selectedRun.performance.elapsed_seconds ?? 0).toFixed(1)} 秒</span><span>排队 {Number(selectedRun.performance.queued_seconds || 0).toFixed(1)} 秒</span><span>汇总 {Number(selectedRun.performance.summary_seconds || 0).toFixed(1)} 秒</span><span>进程内存峰值采样 {(Number(selectedRun.performance.sampled_process_peak_rss_bytes || 0) / 1048576).toFixed(0)} MB</span></div>
                <p className="wb-muted">下表为主流程所处阶段的时间；后台城市生成可能同时进行。“生成业务表”阶段不是所有城市的计算总耗时，阶段与子任务不能相加。</p>
                <button type="button" className="wb-button" onClick={() => saveDownloadBlob(new Blob([JSON.stringify({format_version:1,exported_at:new Date().toISOString(),task:{id:selectedRun.id,cities:selectedRun.cities,start:selectedRun.start,end:selectedRun.end,datasets:selectedRun.datasets,status:selectedRun.status},performance:selectedRun.performance},null,2)],{type:'application/json'}),`性能诊断_${selectedRun.id.slice(0,8)}.json`)}>保存本任务性能诊断（不含人员明细）</button>
                {selectedRun.performance.stages?.source_row_filter && <p className="wb-muted">取分离过滤实际调用累计 {Number(selectedRun.performance.stages.source_row_filter.seconds).toFixed(2)} 秒（包含在上方总耗时内）</p>}
                {selectedRun.performance.stages?.archive_projection && <p className="wb-muted">骑手档案格式化与排序 {Number(selectedRun.performance.stages.archive_projection.seconds).toFixed(2)} 秒（包含在归档阶段内）</p>}
                {selectedRun.performance.scheduler && <p className="wb-muted">本地处理等待 {Number(selectedRun.performance.scheduler.local_queue_seconds).toFixed(2)} 秒；{selectedRun.performance.scheduler.collection_released_before_local_work ? '采集结束后已释放采集队列' : '本任务保持串行采集'}。平台采集串行，本地重任务按任务串行。</p>}
                <dl>{Object.entries(selectedRun.performance.stages || {}).filter(([key]) => key.startsWith('phase:')).map(([key, value]) => <div className="wb-row wb-space" key={key}><dt>{phaseLabel(key.slice(6))}</dt><dd>{Number(value.seconds || 0).toFixed(2)} 秒</dd></div>)}</dl>
                {!!selectedRun.performance.order_pipelines?.length && <div className="space-y-2">{selectedRun.performance.order_pipelines.map((orders, index) => <div key={index}><p className="font-medium">问题单处理{selectedRun.performance!.order_pipelines!.length > 1 ? ` · ${index + 1}` : ''}</p><p className="wb-muted">平台采集 {Number(orders.collection_seconds || 0).toFixed(2)} 秒 · 分批解析 {Number(orders.parser_seconds || 0).toFixed(2)} 秒</p><dl>{Object.entries(orders.timings || {}).filter(([key]) => key in ORDER_TIMING_LABELS).map(([key, seconds]) => <div className="wb-row wb-space" key={key}><dt>{ORDER_TIMING_LABELS[key]}</dt><dd>{Number(seconds).toFixed(2)} 秒</dd></div>)}</dl><p className="wb-muted">采集与处理可能并行，部分阶段包含子阶段，耗时不能直接相加。</p></div>)}</div>}
                {!!selectedRun.performance.generators?.length && <div>{selectedRun.performance.generators.map((generator, index) => <div key={index}><p className="wb-muted">{datasetLabel(generator.name)}{generator.scope ? ` · ${generator.scope.city} · ${generator.scope.month}` : ` · 子任务 ${index + 1}`} · {Number(generator.elapsed_seconds || 0).toFixed(2)} 秒</p>{generator.name === 'abnormal_riders' && <p className="wb-muted pl-3">读取来源 {generator.stages?.read_sources ? `${Number(generator.stages.read_sources.seconds).toFixed(2)} 秒` : '未记录'} · 写入子表 {generator.stages?.write_sheets ? `${Number(generator.stages.write_sheets.seconds).toFixed(2)} 秒` : '未记录'} · 保存压缩 {generator.stages?.save_workbook ? `${Number(generator.stages.save_workbook.seconds).toFixed(2)} 秒` : '未记录'}（均包含在该子任务耗时内）</p>}</div>)}</div>}
                {selectedRun.performance.source_cache && <p className="wb-muted">本任务解析缓存命中 {selectedRun.performance.source_cache.hits} 次；临时大表缓存 {selectedRun.performance.source_cache.spill_files || 0} 份、{((selectedRun.performance.source_cache.spill_bytes || 0) / 1048576).toFixed(1)} MB。任务结束自动清理；内存为服务进程采样，非任务独占。</p>}
              </details>}
              <details className="border-t border-slate-200 pt-3 text-xs text-slate-500"><summary className="cursor-pointer w-fit">任务信息与保存位置</summary><div className="mt-3 space-y-2"><p>编号：{selectedRun.archive_code || selectedRun.id.slice(0, 6).toUpperCase()}</p><p className="break-all">任务目录：{selectedRun.archive_relative_dir || '旧版任务保留原存放位置'}</p><p>城市：{selectedRun.cities.join('、')}</p><p>资料：{selectedRun.datasets.map(datasetLabel).join('、')}</p>{selectedRun.retry_of && <p>此任务处理原任务 {selectedRun.retry_of.slice(0, 6).toUpperCase()} 的未完成项。</p>}{selectedRun.recovery_of && <p>此任务恢复原有平台导出。</p>}{!activeRun && <button type="button" className={smallButton} disabled={rawBusy} onClick={() => void downloadRawBundle()}>下载已保留原始资料</button>}{selectedRun.last_activity_at && <p>最近进展：{displayTime(selectedRun.last_activity_at)}</p>}{!activeRun && <button type="button" className={smallButton} disabled={!!downloadingSummaryId} onClick={() => void downloadSummary()}>{downloadingSummaryId ? <Loader2 size={14} /> : <Download size={14} />}下载说明</button>}</div></details>
              {(() => {
                const otherFiles = (selectedRun.files || []).filter(f => !f.name.endsWith('.xlsx') && !f.name.endsWith('.xls'));
                return otherFiles.length > 0 ? (
                  <details className="wb-original-versions">
                    <summary>中间与原始文件版本 ({otherFiles.length} 个)</summary>
                    <p className="wb-muted">用于核对历史版本；当前可用成品请直接在上方领取。</p>
                    {otherFiles.map(file => (
                      <div className="wb-row wb-space" key={file.id}>
                        <span className="wb-record-filename">{file.name}</span>
                        <button type="button" className="wb-button" disabled={!!fileBusy} onClick={() => void downloadFile(file.id, file.name)}>领取原版本</button>
                      </div>
                    ))}
                  </details>
                ) : null;
              })()}
              {!!selectedRun.logs?.length && <details className="border-t border-slate-200 pt-3 text-xs text-slate-600"><summary className="cursor-pointer w-fit">执行日志</summary><div className="mt-3 max-h-48 space-y-2 overflow-y-auto font-mono bg-slate-50 border border-slate-200 rounded-lg p-3">{selectedRun.logs.map((log, index) => <p key={index} className="break-words"><span className="mr-2 text-slate-400">{displayTime(log.time)}</span>{log.message}</p>)}</div></details>}
            </div>}
        </>}
      />}

    </div>
  );
}
